| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| building | Building_ID | Region_ID references region(Region_ID) | 8 |
| region | Region_ID |  | 11 |
