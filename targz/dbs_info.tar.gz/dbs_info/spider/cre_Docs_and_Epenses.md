| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Accounts | Account_ID | Statement_ID references Statements(Statement_ID) | 15 |
| Documents | Document_ID | Project_ID references Projects(Project_ID), Document_Type_Code references Ref_Document_Types(Document_Type_Code) | 15 |
| Documents_with_Expenses | Document_ID | Document_ID references Documents(Document_ID), Budget_Type_Code references Ref_Budget_Codes(Budget_Type_Code) | 10 |
| Projects | Project_ID |  | 5 |
| Ref_Budget_Codes | Budget_Type_Code |  | 3 |
| Ref_Document_Types | Document_Type_Code |  | 5 |
| Statements | Statement_ID | Statement_ID references Documents(Document_ID) | 2 |
