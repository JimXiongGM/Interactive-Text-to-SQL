| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Features | Feature_ID |  | 5 |
| Hotels | hotel_id | star_rating_code references Ref_Hotel_Star_Ratings(star_rating_code) | 20 |
| Locations | Location_ID |  | 15 |
| Museums | Museum_ID | Museum_ID references Tourist_Attractions(Tourist_Attraction_ID) | 3 |
| Photos | Photo_ID | Tourist_Attraction_ID references Tourist_Attractions(Tourist_Attraction_ID) | 15 |
| Ref_Attraction_Types | Attraction_Type_Code |  | 5 |
| Ref_Hotel_Star_Ratings | star_rating_code |  | 5 |
| Royal_Family | Royal_Family_ID | Royal_Family_ID references Tourist_Attractions(Tourist_Attraction_ID) | 2 |
| Shops | Shop_ID | Shop_ID references Tourist_Attractions(Tourist_Attraction_ID) | 4 |
| Staff | Staff_ID | Tourist_Attraction_ID references Tourist_Attractions(Tourist_Attraction_ID) | 20 |
| Street_Markets | Market_ID | Market_ID references Tourist_Attractions(Tourist_Attraction_ID) | 2 |
| Theme_Parks | Theme_Park_ID | Theme_Park_ID references Tourist_Attractions(Tourist_Attraction_ID) | 3 |
| Tourist_Attraction_Features | Tourist_Attraction_ID | Feature_ID references Features(Feature_ID), Tourist_Attraction_ID references Tourist_Attractions(Tourist_Attraction_ID) | 18 |
| Tourist_Attractions | Tourist_Attraction_ID | Attraction_Type_Code references Ref_Attraction_Types(Attraction_Type_Code), Location_ID references Locations(Location_ID) | 15 |
| Visitors | Tourist_ID |  | 20 |
| Visits | Visit_ID | Tourist_ID references Visitors(Tourist_ID), Tourist_Attraction_ID references Tourist_Attractions(Tourist_Attraction_ID) | 20 |
