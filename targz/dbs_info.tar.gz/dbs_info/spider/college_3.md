| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Course | CID | DNO references Department(DNO), Instructor references Faculty(FacID) | 76 |
| Department | DNO |  | 26 |
| Enrolled_in |  | Grade references Gradeconversion(lettergrade), CID references Course(CID), StuID references Student(StuID) | 210 |
| Faculty | FacID |  | 58 |
| Gradeconversion | lettergrade |  | 13 |
| Member_of |  | DNO references Department(DNO), FacID references Faculty(FacID) | 63 |
| Minor_in |  | DNO references Department(DNO), StuID references Student(StuID) | 10 |
| Student | StuID |  | 34 |
