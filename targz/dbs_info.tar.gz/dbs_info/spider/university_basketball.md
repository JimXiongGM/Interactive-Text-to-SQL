| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| basketball_match | Team_ID | School_ID references university(School_ID) | 4 |
| university | School_ID |  | 5 |
