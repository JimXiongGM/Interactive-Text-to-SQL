| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| game | id | stadium_id references stadium(id) | 20 |
| injury_accident | id | game_id references game(id) | 15 |
| stadium | id |  | 13 |
