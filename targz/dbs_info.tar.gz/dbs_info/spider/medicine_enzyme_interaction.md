| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| enzyme | id |  | 8 |
| medicine | id |  | 21 |
| medicine_enzyme_interaction | enzyme_id | medicine_id references medicine(id), enzyme_id references enzyme(id) | 19 |
