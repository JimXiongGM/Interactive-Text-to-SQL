| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Exams | Exam_ID |  | 9 |
| Questions | Question_ID |  | 14 |
| Questions_in_Exams | Exam_ID | Exam_ID references Exams(Exam_ID), Question_ID references Questions(Question_ID) | 14 |
| Student_Answers | Student_Answer_ID | Exam_ID references Questions_in_Exams(Exam_ID), Question_ID references Questions_in_Exams(Question_ID), Student_ID references Students(Student_ID) | 13 |
| Student_Assessments | Student_Answer_ID | Valid_Answer_ID references Valid_Answers(Valid_Answer_ID) | 15 |
| Students | Student_ID |  | 15 |
| Valid_Answers | Valid_Answer_ID | Question_ID references Questions(Question_ID) | 10 |
