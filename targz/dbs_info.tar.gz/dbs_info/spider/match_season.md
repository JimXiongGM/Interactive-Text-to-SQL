| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| country | Country_id |  | 6 |
| match_season | Season | Team references team(Team_id), Country references country(Country_id) | 16 |
| player | Player_ID | Team references team(Team_id) | 10 |
| team | Team_id |  | 10 |
