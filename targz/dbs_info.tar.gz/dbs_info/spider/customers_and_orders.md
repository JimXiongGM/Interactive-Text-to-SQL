| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Addresses | address_id |  | 15 |
| Customer_Orders | order_id | customer_id references Customers(customer_id) | 15 |
| Customers | customer_id |  | 15 |
| Order_Items |  | product_id references Products(product_id), order_id references Customer_Orders(order_id) | 15 |
| Products | product_id |  | 15 |
