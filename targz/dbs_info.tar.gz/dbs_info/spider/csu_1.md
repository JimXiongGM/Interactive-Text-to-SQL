| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Campuses | Id |  | 23 |
| csu_fees | Campus | Campus references Campuses(Id) | 23 |
| degrees | Year | Campus references Campuses(Id) | 320 |
| discipline_enrollments | Campus | Campus references Campuses(Id) | 395 |
| enrollments | Campus | Campus references Campuses(Id) | 1113 |
| faculty |  | Campus references Campuses(Id) | 69 |
