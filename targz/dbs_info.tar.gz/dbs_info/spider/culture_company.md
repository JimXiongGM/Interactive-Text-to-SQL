| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| book_club | book_club_id |  | 12 |
| culture_company | Company_name | movie_id references movie(movie_id), book_club_id references book_club(book_club_id) | 6 |
| movie | movie_id |  | 10 |
