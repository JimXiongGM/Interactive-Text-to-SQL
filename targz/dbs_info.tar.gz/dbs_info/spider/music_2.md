| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Albums | AId |  | 0 |
| Band | Id |  | 0 |
| Instruments | SongId | BandmateId references Band(Id), SongId references Songs(SongId) | 0 |
| Performance | SongId | Bandmate references Band(Id), SongId references Songs(SongId) | 0 |
| Songs | SongId |  | 0 |
| Tracklists | AlbumId | AlbumId references Albums(AId), SongId references Songs(SongId) | 0 |
| Vocals | SongId | Bandmate references Band(Id), SongId references Songs(SongId) | 0 |
