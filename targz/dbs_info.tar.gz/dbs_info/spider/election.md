| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| county | County_Id |  | 5 |
| election | Election_ID | District references county(County_Id), Party references party(Party_ID) | 8 |
| party | Party_ID |  | 7 |
