| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| event | Event_ID |  | 5 |
| journalist | journalist_ID |  | 11 |
| news_report | journalist_ID | Event_ID references event(Event_ID), journalist_ID references journalist(journalist_ID) | 7 |
