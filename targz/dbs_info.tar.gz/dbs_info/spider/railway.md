| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| manager | Manager_ID |  | 7 |
| railway | Railway_ID |  | 10 |
| railway_manage | Railway_ID | Railway_ID references railway(Railway_ID), Manager_ID references manager(Manager_ID) | 4 |
| train | Train_ID | Railway_ID references railway(Railway_ID) | 9 |
