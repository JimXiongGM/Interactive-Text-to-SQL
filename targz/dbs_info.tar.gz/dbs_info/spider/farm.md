| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| city | City_ID |  | 5 |
| competition_record | Competition_ID | Farm_ID references farm(Farm_ID), Competition_ID references farm_competition(Competition_ID) | 12 |
| farm | Farm_ID |  | 8 |
| farm_competition | Competition_ID | Host_city_ID references city(City_ID) | 6 |
