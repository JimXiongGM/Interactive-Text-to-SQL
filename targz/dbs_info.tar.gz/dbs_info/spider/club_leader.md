| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| club | Club_ID |  | 12 |
| club_leader | Club_ID | Member_ID references member(Member_ID), Club_ID references club(Club_ID) | 6 |
| member | Member_ID |  | 10 |
