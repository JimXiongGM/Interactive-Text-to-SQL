| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| book | Book_ID |  | 10 |
| publication | Publication_ID | Book_ID references book(Book_ID) | 7 |
