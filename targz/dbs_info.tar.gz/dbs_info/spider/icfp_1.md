| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Authors | authID |  | 13 |
| Authorship | authID | paperID references Papers(paperID), instID references Inst(instID), authID references Authors(authID) | 14 |
| Inst | instID |  | 8 |
| Papers | paperID |  | 7 |
