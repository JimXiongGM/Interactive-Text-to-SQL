| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Plays_Games |  | StuID references Student(StuID), GameID references Video_Games(GameID) | 10 |
| SportsInfo |  | StuID references Student(StuID) | 14 |
| Student | StuID |  | 34 |
| Video_Games | GameID |  | 6 |
