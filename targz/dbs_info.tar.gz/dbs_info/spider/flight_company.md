| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| airport | id |  | 9 |
| flight | id | company_id references operate_company(id), airport_id references airport(id) | 13 |
| operate_company | id |  | 14 |
