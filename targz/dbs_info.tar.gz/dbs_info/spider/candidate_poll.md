| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| candidate | Candidate_ID | People_ID references people(People_ID) | 6 |
| people | People_ID |  | 9 |
