| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Attribute_Definitions | attribute_id |  | 4 |
| Catalog_Contents | catalog_entry_id | catalog_level_number references Catalog_Structure(catalog_level_number) | 15 |
| Catalog_Contents_Additional_Attributes |  | attribute_id references Attribute_Definitions(attribute_id) | 15 |
| Catalog_Structure | catalog_level_number | catalog_id references Catalogs(catalog_id) | 3 |
| Catalogs | catalog_id |  | 8 |
