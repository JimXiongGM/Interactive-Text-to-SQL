| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| college | College_ID |  | 5 |
| member | Member_ID | College_ID references college(College_ID) | 10 |
| round | Member_ID | Member_ID references member(Member_ID) | 6 |
