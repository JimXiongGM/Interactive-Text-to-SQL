| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| author | Author_ID |  | 7 |
| book | Book_ID | Press_ID references press(Press_ID), Author_ID references author(Author_ID) | 10 |
| press | Press_ID |  | 10 |
