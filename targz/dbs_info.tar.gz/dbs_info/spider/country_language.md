| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| countries | id |  | 9 |
| languages | id |  | 10 |
| official_languages | language_id | country_id references countries(id), language_id references languages(id) | 12 |
