| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Characteristics | characteristic_id | characteristic_type_code references Ref_Characteristic_Types(characteristic_type_code) | 15 |
| Product_Characteristics |  | product_id references Products(product_id), characteristic_id references Characteristics(characteristic_id) | 15 |
| Products | product_id | color_code references Ref_Colors(color_code), product_category_code references Ref_Product_Categories(product_category_code) | 15 |
| Ref_Characteristic_Types | characteristic_type_code |  | 2 |
| Ref_Colors | color_code |  | 8 |
| Ref_Product_Categories | product_category_code |  | 3 |
