| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Addresses | address_id |  | 15 |
| Customer_Payments | customer_id | customer_id references Customers(customer_id) | 15 |
| Customers | customer_id | customer_address_id references Addresses(address_id) | 15 |
| Lessons | lesson_id | customer_id references Customers(customer_id), staff_id references Staff(staff_id), vehicle_id references Vehicles(vehicle_id) | 15 |
| Staff | staff_id | staff_address_id references Addresses(address_id) | 15 |
| Vehicles | vehicle_id |  | 3 |
