| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| driver | Driver_ID |  | 11 |
| race | Road | Driver_ID references driver(Driver_ID) | 9 |
