| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Person | name |  | 4 |
| PersonFriend |  | friend references Person(name), name references Person(name) | 4 |
