| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| body_builder | Body_Builder_ID | People_ID references people(People_ID) | 5 |
| people | People_ID |  | 6 |
