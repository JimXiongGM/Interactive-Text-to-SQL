| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| channel | Channel_ID |  | 14 |
| director | Director_ID |  | 10 |
| director_admin | Director_ID | Channel_ID references channel(Channel_ID), Director_ID references director(Director_ID) | 5 |
| program | Program_ID | Channel_ID references channel(Channel_ID), Director_ID references director(Director_ID) | 8 |
