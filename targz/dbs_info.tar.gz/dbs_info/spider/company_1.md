| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| department | Dnumber | Dnumber references dept_locations(dnumber) | 3 |
| dependent | Essn |  | 7 |
| dept_locations | Dnumber |  | 5 |
| employee | Ssn |  | 8 |
| project | Pnumber |  | 6 |
| works_on | Essn |  | 16 |
