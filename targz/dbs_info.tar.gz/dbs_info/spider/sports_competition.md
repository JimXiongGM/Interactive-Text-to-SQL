| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| club | Club_ID |  | 6 |
| club_rank | Rank | Club_ID references club(Club_ID) | 6 |
| competition | Competition_ID |  | 11 |
| competition_result | Competition_ID | Competition_ID references competition(Competition_ID), Club_ID_2 references club(Club_ID), Club_ID_1 references club(Club_ID) | 6 |
| player | Player_ID | Club_ID references club(Club_ID) | 15 |
