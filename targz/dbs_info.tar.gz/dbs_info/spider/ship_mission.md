| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| mission | Mission_ID | Ship_ID references ship(Ship_ID) | 7 |
| ship | Ship_ID |  | 8 |
