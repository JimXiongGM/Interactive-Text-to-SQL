| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Apartment_Bookings | apt_booking_id | guest_id references Guests(guest_id), apt_id references Apartments(apt_id) | 15 |
| Apartment_Buildings | building_id |  | 15 |
| Apartment_Facilities | apt_id | apt_id references Apartments(apt_id) | 7 |
| Apartments | apt_id | building_id references Apartment_Buildings(building_id) | 15 |
| Guests | guest_id |  | 15 |
| View_Unit_Status | status_date | apt_booking_id references Apartment_Bookings(apt_booking_id), apt_id references Apartments(apt_id) | 20 |
