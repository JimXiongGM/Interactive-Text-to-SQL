| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Addresses | address_id |  | 15 |
| Courses | course_id |  | 15 |
| Degree_Programs | degree_program_id | department_id references Departments(department_id) | 15 |
| Departments | department_id |  | 15 |
| Sections | section_id | course_id references Courses(course_id) | 15 |
| Semesters | semester_id |  | 15 |
| Student_Enrolment | student_enrolment_id | student_id references Students(student_id), semester_id references Semesters(semester_id), degree_program_id references Degree_Programs(degree_program_id) | 15 |
| Student_Enrolment_Courses | student_course_id | student_enrolment_id references Student_Enrolment(student_enrolment_id), course_id references Courses(course_id) | 15 |
| Students | student_id | permanent_address_id references Addresses(address_id), current_address_id references Addresses(address_id) | 15 |
| Transcript_Contents |  | transcript_id references Transcripts(transcript_id), student_course_id references Student_Enrolment_Courses(student_course_id) | 15 |
| Transcripts | transcript_id |  | 15 |
