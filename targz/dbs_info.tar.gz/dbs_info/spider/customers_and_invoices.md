| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Accounts | account_id | customer_id references Customers(customer_id) | 15 |
| Customers | customer_id |  | 15 |
| Financial_Transactions |  | account_id references Accounts(account_id), invoice_number references Invoices(invoice_number) | 15 |
| Invoice_Line_Items |  | product_id references Products(product_id), invoice_number references Invoices(invoice_number), order_item_id references Order_Items(order_item_id) | 15 |
| Invoices | invoice_number | order_id references Orders(order_id) | 15 |
| Order_Items | order_item_id | order_id references Orders(order_id), product_id references Products(product_id) | 15 |
| Orders | order_id | customer_id references Customers(customer_id) | 15 |
| Product_Categories | production_type_code |  | 4 |
| Products | product_id | production_type_code references Product_Categories(production_type_code) | 15 |
