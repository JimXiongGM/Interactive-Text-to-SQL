| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| furniture | Furniture_ID |  | 7 |
| furniture_manufacte | Manufacturer_ID | Furniture_ID references furniture(Furniture_ID), Manufacturer_ID references manufacturer(Manufacturer_ID) | 5 |
| manufacturer | Manufacturer_ID |  | 7 |
