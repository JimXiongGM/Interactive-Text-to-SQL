| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| appellations | No |  | 57 |
| grapes | ID |  | 20 |
| wine |  | Appelation references appellations(Appelation), Grape references grapes(Grape) | 500 |
