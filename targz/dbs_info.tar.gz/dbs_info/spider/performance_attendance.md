| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| member | Member_ID |  | 11 |
| member_attendance | Member_ID | Performance_ID references performance(Performance_ID), Member_ID references member(Member_ID) | 8 |
| performance | Performance_ID |  | 6 |
