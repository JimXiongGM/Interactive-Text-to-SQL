| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| artwork | Artwork_ID |  | 9 |
| festival_detail | Festival_ID |  | 5 |
| nomination | Artwork_ID | Festival_ID references festival_detail(Festival_ID), Artwork_ID references artwork(Artwork_ID) | 6 |
