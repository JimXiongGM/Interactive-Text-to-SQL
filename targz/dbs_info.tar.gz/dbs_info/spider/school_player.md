| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| player | Player_ID | School_ID references school(School_ID) | 23 |
| school | School_ID |  | 6 |
| school_details | School_ID | School_ID references school(School_ID) | 6 |
| school_performance | School_Id | School_Id references school(School_ID) | 22 |
