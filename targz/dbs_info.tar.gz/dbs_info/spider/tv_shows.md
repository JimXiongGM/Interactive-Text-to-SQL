| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| city_channel | ID |  | 14 |
| city_channel_radio | City_channel_ID | Radio_ID references radio(Radio_ID), City_channel_ID references city_channel(ID) | 10 |
| city_channel_tv_show | City_channel_ID | tv_show_ID references tv_show(tv_show_ID), City_channel_ID references city_channel(ID) | 8 |
| radio | Radio_ID |  | 7 |
| tv_show | tv_show_ID |  | 12 |
