| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Country | id |  | 11 |
| League | id | country_id references Country(id) | 11 |
| Player | id |  | 11060 |
| Player_Attributes | id | player_api_id references Player(player_api_id), player_fifa_api_id references Player(player_fifa_api_id) | 183978 |
| Team | id |  | 299 |
| Team_Attributes | id | team_api_id references Team(team_api_id), team_fifa_api_id references Team(team_fifa_api_id) | 1458 |
