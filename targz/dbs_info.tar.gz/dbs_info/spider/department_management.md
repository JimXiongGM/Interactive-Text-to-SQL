| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| department | Department_ID |  | 15 |
| head | head_ID |  | 10 |
| management | department_ID | head_ID references head(head_ID), department_ID references department(Department_ID) | 5 |
