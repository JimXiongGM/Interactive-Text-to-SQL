| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| all_star |  | player_id references player(player_id) | 5069 |
| appearances |  | player_id references player(player_id), team_id references team(team_id) | 100951 |
| batting |  | player_id references player(player_id) | 101332 |
| batting_postseason |  | team_id references team(team_id), player_id references player(player_id) | 11690 |
| college |  |  | 1207 |
| fielding |  | player_id references player(player_id) | 170526 |
| fielding_outfield |  | player_id references player(player_id) | 12028 |
| fielding_postseason |  | team_id references player(team_id), player_id references player(player_id) | 12311 |
| hall_of_fame |  | player_id references player(player_id) | 4120 |
| home_game |  | park_id references park(park_id), team_id references team(team_id) | 2944 |
| manager |  | team_id references team(team_id) | 3405 |
| manager_award |  | player_id references player(player_id) | 177 |
| manager_award_vote |  |  | 414 |
| manager_half |  | team_id references team(team_id) | 93 |
| park |  |  | 250 |
| pitching |  |  | 44139 |
| pitching_postseason |  |  | 5109 |
| player |  |  | 18846 |
| player_award |  | player_id references player(player_id) | 6078 |
| player_award_vote |  | player_id references player(player_id) | 6795 |
| player_college |  | college_id references college(college_id), player_id references player(player_id) | 17350 |
| postseason |  |  | 307 |
| salary |  | player_id references player(player_id), team_id references team(team_id_br) | 25575 |
| team |  |  | 2805 |
| team_franchise |  |  | 120 |
| team_half |  |  | 52 |
