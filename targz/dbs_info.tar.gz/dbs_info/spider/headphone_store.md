| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| headphone | Headphone_ID |  | 11 |
| stock | Store_ID | Headphone_ID references headphone(Headphone_ID), Store_ID references store(Store_ID) | 8 |
| store | Store_ID |  | 9 |
