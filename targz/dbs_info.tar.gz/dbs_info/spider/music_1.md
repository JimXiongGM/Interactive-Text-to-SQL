| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| artist | artist_name | preferred_genre references genre(g_name) | 6 |
| files | f_id | artist_name references artist(artist_name) | 6 |
| genre | g_name |  | 6 |
| song | song_name | genre_is references genre(g_name), f_id references files(f_id), artist_name references artist(artist_name) | 6 |
