| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| list | LastName | Classroom references teachers(classroom) | 60 |
| teachers | LastName |  | 12 |
