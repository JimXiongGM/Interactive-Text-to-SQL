| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| MovieTheaters | Code | Movie references Movies(Code) | 6 |
| Movies | Code |  | 8 |
