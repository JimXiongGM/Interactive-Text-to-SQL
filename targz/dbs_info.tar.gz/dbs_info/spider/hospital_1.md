| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Affiliated_With | Physician | Department references Department(DepartmentID), Physician references Physician(EmployeeID) | 11 |
| Appointment | AppointmentID | Physician references Physician(EmployeeID), PrepNurse references Nurse(EmployeeID), Patient references Patient(SSN) | 9 |
| Block | BlockFloor |  | 12 |
| Department | DepartmentID | Head references Physician(EmployeeID) | 3 |
| Medication | Code |  | 5 |
| Nurse | EmployeeID |  | 3 |
| On_Call | Nurse | BlockFloor references Block(BlockFloor), BlockCode references Block(BlockCode), Nurse references Nurse(EmployeeID) | 6 |
| Patient | SSN | PCP references Physician(EmployeeID) | 4 |
| Physician | EmployeeID |  | 9 |
| Prescribes | Physician | Appointment references Appointment(AppointmentID), Medication references Medication(Code), Patient references Patient(SSN), Physician references Physician(EmployeeID) | 3 |
| Procedures | Code |  | 7 |
| Room | RoomNumber | BlockFloor references Block(BlockFloor), BlockCode references Block(BlockCode) | 36 |
| Stay | StayID | Room references Room(RoomNumber), Patient references Patient(SSN) | 3 |
| Trained_In | Physician | Treatment references Procedures(Code), Physician references Physician(EmployeeID) | 15 |
| Undergoes | Patient | AssistingNurse references Nurse(EmployeeID), Physician references Physician(EmployeeID), Stay references Stay(StayID), Procedures references Procedures(Code), Patient references Patient(SSN) | 6 |
