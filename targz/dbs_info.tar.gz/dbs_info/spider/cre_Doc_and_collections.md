| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Collection_Subset_Members | Collection_ID | Collection_Subset_ID references Collection_Subsets(Collection_Subset_ID), Related_Collection_ID references Collections(Collection_ID), Collection_ID references Collections(Collection_ID) | 4 |
| Collection_Subsets | Collection_Subset_ID |  | 7 |
| Collections | Collection_ID |  | 2 |
| Document_Objects | Document_Object_ID |  | 3 |
| Document_Subset_Members | Document_Object_ID | Document_Subset_ID references Document_Subsets(Document_Subset_ID), Related_Document_Object_ID references Document_Objects(Document_Object_ID), Document_Object_ID references Document_Objects(Document_Object_ID) | 8 |
| Document_Subsets | Document_Subset_ID |  | 8 |
| Documents_in_Collections | Document_Object_ID | Collection_ID references Collections(Collection_ID), Document_Object_ID references Document_Objects(Document_Object_ID) | 6 |
