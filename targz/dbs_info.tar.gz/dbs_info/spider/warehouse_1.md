| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Boxes | Code | Warehouse references Warehouses(Code) | 11 |
| Warehouses | Code |  | 5 |
