| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| singer | Singer_ID |  | 8 |
| song | Song_ID | Singer_ID references singer(Singer_ID) | 8 |
