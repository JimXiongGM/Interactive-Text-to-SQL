| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| albums | id | artist_id references artists(id) | 347 |
| artists | id |  | 275 |
| customers | id | support_rep_id references employees(id) | 59 |
| employees | id | reports_to references employees(id) | 8 |
| genres | id |  | 25 |
| invoice_lines | id | track_id references tracks(id), invoice_id references invoices(id) | 2240 |
| invoices | id | customer_id references customers(id) | 412 |
| media_types | id |  | 5 |
| playlist_tracks | playlist_id | track_id references tracks(id), playlist_id references playlists(id) | 8715 |
| playlists | id |  | 18 |
| tracks | id | media_type_id references media_types(id), genre_id references genres(id), album_id references albums(id) | 3503 |
