| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Friend | student_id | friend_id references Highschooler(ID), student_id references Highschooler(ID) | 20 |
| Highschooler | ID |  | 16 |
| Likes | student_id | student_id references Highschooler(ID), liked_id references Highschooler(ID) | 10 |
