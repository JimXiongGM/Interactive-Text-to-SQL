| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| club | Club_ID |  | 6 |
| coach | Coach_ID | Club_ID references club(Club_ID) | 5 |
| match_result | Rank | Club_ID references club(Club_ID) | 6 |
| player | Player_ID |  | 14 |
| player_coach | Player_ID | Coach_ID references coach(Coach_ID), Player_ID references player(Player_ID) | 7 |
