| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| countries | COUNTRY_ID | REGION_ID references regions(REGION_ID) | 25 |
| departments | DEPARTMENT_ID |  | 27 |
| employees | EMPLOYEE_ID | JOB_ID references jobs(JOB_ID), DEPARTMENT_ID references departments(DEPARTMENT_ID) | 107 |
| job_history | EMPLOYEE_ID | JOB_ID references jobs(JOB_ID), DEPARTMENT_ID references departments(DEPARTMENT_ID), EMPLOYEE_ID references employees(EMPLOYEE_ID) | 11 |
| jobs | JOB_ID |  | 19 |
| locations | LOCATION_ID | COUNTRY_ID references countries(COUNTRY_ID) | 23 |
| regions | REGION_ID |  | 4 |
