| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Boats | bid |  | 3 |
| Reserves |  | bid references Boats(bid), sid references Sailors(sid) | 4 |
| Sailors | sid |  | 3 |
