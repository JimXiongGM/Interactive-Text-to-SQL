| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| aircraft | Aircraft_ID |  | 7 |
| pilot | Pilot_ID |  | 5 |
| pilot_record | Pilot_ID | Aircraft_ID references aircraft(Aircraft_ID), Pilot_ID references pilot(Pilot_ID) | 6 |
