| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Problem_Category_Codes | problem_category_code |  | 3 |
| Problem_Log | problem_log_id | problem_status_code references Problem_Status_Codes(problem_status_code), problem_id references Problems(problem_id), assigned_to_staff_id references Staff(staff_id), problem_category_code references Problem_Category_Codes(problem_category_code) | 15 |
| Problem_Status_Codes | problem_status_code |  | 2 |
| Problems | problem_id | reported_by_staff_id references Staff(staff_id), product_id references Product(product_id), closure_authorised_by_staff_id references Staff(staff_id) | 15 |
| Product | product_id |  | 15 |
| Staff | staff_id |  | 15 |
