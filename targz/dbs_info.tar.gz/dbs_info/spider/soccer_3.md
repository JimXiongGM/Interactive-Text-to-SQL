| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| club | Club_ID |  | 9 |
| player | Player_ID | Club_ID references club(Club_ID) | 5 |
