| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Addresses | address_id |  | 20 |
| Assessment_Notes |  | teacher_id references Teachers(teacher_id), student_id references Students(student_id) | 15 |
| Behavior_Incident | incident_id | student_id references Students(student_id), incident_type_code references Ref_Incident_Type(incident_type_code) | 15 |
| Detention | detention_id | teacher_id references Teachers(teacher_id), detention_type_code references Ref_Detention_Type(detention_type_code) | 15 |
| Ref_Address_Types | address_type_code |  | 2 |
| Ref_Detention_Type | detention_type_code |  | 3 |
| Ref_Incident_Type | incident_type_code |  | 3 |
| Student_Addresses |  | student_id references Students(student_id), address_id references Addresses(address_id) | 20 |
| Students | student_id | address_id references Addresses(address_id) | 15 |
| Students_in_Detention |  | student_id references Students(student_id), detention_id references Detention(detention_id), incident_id references Behavior_Incident(incident_id) | 15 |
| Teachers | teacher_id | address_id references Addresses(address_id) | 15 |
