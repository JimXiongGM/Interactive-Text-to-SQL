| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Addresses | Address_ID |  | 20 |
| Bookings | Booking_ID | Workshop_Group_ID references Drama_Workshop_Groups(Workshop_Group_ID), Customer_ID references Clients(Client_ID) | 15 |
| Bookings_Services | Order_ID | Product_ID references Services(Service_ID), Order_ID references Bookings(Booking_ID) | 12 |
| Clients | Client_ID | Address_ID references Addresses(Address_ID) | 20 |
| Customer_Orders | Order_ID | Store_ID references Stores(Store_ID), Customer_ID references Customers(Customer_ID) | 15 |
| Customers | Customer_ID | Address_ID references Addresses(Address_ID) | 15 |
| Drama_Workshop_Groups | Workshop_Group_ID | Address_ID references Addresses(Address_ID) | 15 |
| Invoice_Items | Invoice_Item_ID | Order_ID references Bookings_Services(Order_ID), Product_ID references Bookings_Services(Product_ID), Invoice_ID references Invoices(Invoice_ID), Order_Item_ID references Order_Items(Order_Item_ID) | 2 |
| Invoices | Invoice_ID | payment_method_code references Ref_Payment_Methods(payment_method_code), Order_ID references Bookings(Booking_ID), Order_ID references Customer_Orders(Order_ID) | 15 |
| Marketing_Regions | Marketing_Region_Code |  | 8 |
| Order_Items | Order_Item_ID | Product_ID references Products(Product_ID), Order_ID references Customer_Orders(Order_ID) | 15 |
| Performers | Performer_ID | Address_ID references Addresses(Address_ID) | 20 |
| Performers_in_Bookings | Order_ID | Order_ID references Bookings(Booking_ID), Performer_ID references Performers(Performer_ID) | 18 |
| Products | Product_ID |  | 15 |
| Ref_Payment_Methods | payment_method_code |  | 3 |
| Ref_Service_Types | Service_Type_Code |  | 4 |
| Services | Service_ID | Service_Type_Code references Ref_Service_Types(Service_Type_Code), Workshop_Group_ID references Drama_Workshop_Groups(Workshop_Group_ID) | 15 |
| Stores | Store_ID | Marketing_Region_Code references Marketing_Regions(Marketing_Region_Code), Address_ID references Addresses(Address_ID) | 10 |
