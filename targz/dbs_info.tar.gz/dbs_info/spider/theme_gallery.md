| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| artist | Artist_ID |  | 7 |
| exhibition | Exhibition_ID | Artist_ID references artist(Artist_ID) | 6 |
| exhibition_record | Exhibition_ID | Exhibition_ID references exhibition(Exhibition_ID) | 13 |
