| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Customer_Addresses |  | customer_id references Customers(customer_id), premise_id references Premises(premise_id) | 15 |
| Customer_Orders | order_id | customer_id references Customers(customer_id) | 15 |
| Customers | customer_id |  | 15 |
| Mailshot_Campaigns | mailshot_id |  | 20 |
| Mailshot_Customers |  | mailshot_id references Mailshot_Campaigns(mailshot_id), customer_id references Customers(customer_id) | 15 |
| Order_Items |  | order_id references Customer_Orders(order_id), product_id references Products(product_id) | 15 |
| Premises | premise_id |  | 15 |
| Products | product_id |  | 15 |
