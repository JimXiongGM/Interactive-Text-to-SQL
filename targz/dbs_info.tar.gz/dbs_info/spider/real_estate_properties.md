| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Other_Available_Features | feature_id | feature_type_code references Ref_Feature_Types(feature_type_code) | 3 |
| Other_Property_Features |  | property_id references Properties(property_id), feature_id references Other_Available_Features(feature_id) | 15 |
| Properties | property_id | property_type_code references Ref_Property_Types(property_type_code) | 15 |
| Ref_Feature_Types | feature_type_code |  | 2 |
| Ref_Property_Types | property_type_code |  | 5 |
