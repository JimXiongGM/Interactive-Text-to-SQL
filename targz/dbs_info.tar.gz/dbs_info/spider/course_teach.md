| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| course | Course_ID |  | 10 |
| course_arrange | Course_ID | Teacher_ID references teacher(Teacher_ID), Course_ID references course(Course_ID) | 6 |
| teacher | Teacher_ID |  | 7 |
