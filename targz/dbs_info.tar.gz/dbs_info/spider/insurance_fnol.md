| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Available_Policies | Policy_ID |  | 15 |
| Claims | Claim_ID | FNOL_ID references First_Notification_of_Loss(FNOL_ID) | 10 |
| Customers | Customer_ID |  | 15 |
| Customers_Policies | Customer_ID | Policy_ID references Available_Policies(Policy_ID), Customer_ID references Customers(Customer_ID) | 14 |
| First_Notification_of_Loss | FNOL_ID | Customer_ID references Customers_Policies(Customer_ID), Policy_ID references Customers_Policies(Policy_ID), Service_ID references Services(Service_ID) | 7 |
| Services | Service_ID |  | 4 |
| Settlements | Settlement_ID | Claim_ID references Claims(Claim_ID) | 10 |
