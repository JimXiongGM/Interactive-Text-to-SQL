| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Web_client_accelerator | id |  | 19 |
| accelerator_compatible_browser | accelerator_id | browser_id references browser(id), accelerator_id references Web_client_accelerator(id) | 9 |
| browser | id |  | 4 |
