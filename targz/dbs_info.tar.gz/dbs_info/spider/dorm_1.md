| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Dorm |  |  | 7 |
| Dorm_amenity |  |  | 12 |
| Has_amenity |  | amenid references Dorm_amenity(amenid), dormid references Dorm(dormid) | 40 |
| Lives_in |  | dormid references Dorm(dormid), stuid references Student(StuID) | 31 |
| Student | StuID |  | 34 |
