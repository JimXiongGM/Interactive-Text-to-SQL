| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Institution | Institution_id | building_id references building(building_id) | 11 |
| building | building_id |  | 8 |
| protein | common_name | Institution_id references Institution(Institution_id) | 5 |
