| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Customers | id |  | 5 |
| Discount | id |  | 5 |
| Renting_history | id | discount_id references Discount(id), vehicles_id references Vehicles(id), customer_id references Customers(id) | 7 |
| Vehicles | id |  | 7 |
