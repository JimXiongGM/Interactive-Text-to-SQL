| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| people | People_ID |  | 11 |
| perpetrator | Perpetrator_ID | People_ID references people(People_ID) | 5 |
