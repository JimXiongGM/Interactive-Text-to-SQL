| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| conductor | Conductor_ID |  | 12 |
| orchestra | Orchestra_ID | Conductor_ID references conductor(Conductor_ID) | 12 |
| performance | Performance_ID | Orchestra_ID references orchestra(Orchestra_ID) | 11 |
| show |  | Performance_ID references performance(Performance_ID) | 5 |
