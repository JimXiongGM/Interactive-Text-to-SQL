| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| architect | id |  | 5 |
| bridge | id | architect_id references architect(id) | 15 |
| mill | id | architect_id references architect(id) | 6 |
