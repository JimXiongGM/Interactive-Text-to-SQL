| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Accounts | account_id |  | 15 |
| Customers | customer_id | customer_id references Accounts(customer_id) | 15 |
| Customers_cards | card_id | customer_id references Customers(customer_id) | 15 |
| Financial_Transactions |  | account_id references Accounts(account_id), card_id references Customers_Cards(card_id) | 15 |
