| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| conference | Conference_ID |  | 6 |
| conference_participation | staff_ID | Conference_ID references conference(Conference_ID), staff_ID references staff(staff_ID) | 9 |
| institution | Institution_ID |  | 10 |
| staff | staff_ID | Institution_ID references institution(Institution_ID) | 7 |
