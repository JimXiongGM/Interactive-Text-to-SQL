| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| follows | f1 | f2 references user_profiles(uid), f1 references user_profiles(uid) | 9 |
| tweets | id | uid references user_profiles(uid) | 8 |
| user_profiles | uid |  | 7 |
