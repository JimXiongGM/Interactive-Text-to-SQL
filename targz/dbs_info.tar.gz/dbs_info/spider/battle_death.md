| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| battle | id |  | 8 |
| death | id | caused_by_ship_id references ship(id) | 13 |
| ship | id | lost_in_battle references battle(id) | 7 |
