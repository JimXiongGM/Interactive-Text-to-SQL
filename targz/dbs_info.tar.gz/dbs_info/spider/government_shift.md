| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Analytical_Layer | Analytical_ID | Customers_and_Services_ID references Customers_and_Services(Customers_and_Services_ID) | 15 |
| Channels | Channel_ID |  | 5 |
| Customer_Interactions | Customer_Interaction_ID | Customer_ID references Customers(Customer_ID), Channel_ID references Channels(Channel_ID), Service_ID references Services(Service_ID) | 15 |
| Customers | Customer_ID |  | 15 |
| Customers_and_Services | Customers_and_Services_ID | Customer_ID references Customers(Customer_ID), Service_ID references Services(Service_ID) | 20 |
| Integration_Platform | Integration_Platform_ID | Customer_Interaction_ID references Customer_Interactions(Customer_Interaction_ID) | 15 |
| Services | Service_ID |  | 7 |
