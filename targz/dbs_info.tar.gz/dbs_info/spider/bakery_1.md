| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| customers | Id |  | 20 |
| goods | Id |  | 40 |
| items | Receipt | Item references goods(Id) | 557 |
| receipts | ReceiptNumber | CustomerId references customers(Id) | 200 |
