| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| artist | Artist_ID |  | 7 |
| music_festival | ID | Volume references volume(Volume_ID) | 9 |
| volume | Volume_ID | Artist_ID references artist(Artist_ID) | 10 |
