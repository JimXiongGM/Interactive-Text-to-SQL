| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Investors | investor_id |  | 20 |
| Lots | lot_id | investor_id references Investors(investor_id) | 15 |
| Purchases |  | purchase_transaction_id references Transactions(transaction_id) | 15 |
| Ref_Transaction_Types | transaction_type_code |  | 2 |
| Sales | sales_transaction_id | sales_transaction_id references Transactions(transaction_id) | 15 |
| Transactions | transaction_id | transaction_type_code references Ref_Transaction_Types(transaction_type_code), investor_id references Investors(investor_id) | 15 |
| Transactions_Lots |  | transaction_id references Transactions(transaction_id), lot_id references Lots(lot_id) | 15 |
