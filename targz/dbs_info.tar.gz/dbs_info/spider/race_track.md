| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| race | Race_ID | Track_ID references track(Track_ID) | 7 |
| track | Track_ID |  | 9 |
