| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Bookings | booking_id | customer_id references Customers(customer_id) | 15 |
| Customers | customer_id | coupon_id references Discount_Coupons(coupon_id) | 15 |
| Discount_Coupons | coupon_id |  | 15 |
| Payments | payment_id | customer_id references Customers(customer_id), booking_id references Bookings(booking_id) | 15 |
| Products_Booked | booking_id | product_id references Products_for_Hire(product_id), booking_id references Bookings(booking_id) | 12 |
| Products_for_Hire | product_id |  | 5 |
| View_Product_Availability | status_date | product_id references Products_for_Hire(product_id), booking_id references Bookings(booking_id) | 4 |
