| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| book | Book_ID |  | 5 |
| review | Review_ID | Book_ID references book(Book_ID) | 4 |
