| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Events | Event_ID | Service_ID references Services(Service_ID) | 15 |
| Participants | Participant_ID |  | 15 |
| Participants_in_Events | Event_ID | Event_ID references Events(Event_ID), Participant_ID references Participants(Participant_ID) | 18 |
| Services | Service_ID |  | 4 |
