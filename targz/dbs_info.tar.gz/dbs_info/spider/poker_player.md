| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| people | People_ID |  | 7 |
| poker_player | Poker_Player_ID | People_ID references people(People_ID) | 5 |
