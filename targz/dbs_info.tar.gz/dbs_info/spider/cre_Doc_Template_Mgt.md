| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Documents | Document_ID | Template_ID references Templates(Template_ID) | 15 |
| Paragraphs | Paragraph_ID | Document_ID references Documents(Document_ID) | 15 |
| Ref_Template_Types | Template_Type_Code |  | 5 |
| Templates | Template_ID | Template_Type_Code references Ref_Template_Types(Template_Type_Code) | 20 |
