| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| airlines | alid |  | 6162 |
| airports | apid |  | 7184 |
| routes | rid | alid references airlines(alid), src_apid references airports(apid), dst_apid references airports(apid) | 67240 |
