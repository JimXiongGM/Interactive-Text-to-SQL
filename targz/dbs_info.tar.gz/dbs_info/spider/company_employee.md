| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| company | Company_ID |  | 19 |
| employment | Company_ID | People_ID references people(People_ID), Company_ID references company(Company_ID) | 5 |
| people | People_ID |  | 7 |
