| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Document_Types | document_type_code |  | 2 |
| Documents | document_id | grant_id references Grants(grant_id), document_type_code references Document_Types(document_type_code) | 15 |
| Grants | grant_id | organisation_id references Organisations(organisation_id) | 15 |
| Organisation_Types | organisation_type |  | 2 |
| Organisations | organisation_id | organisation_type references Organisation_Types(organisation_type) | 15 |
| Project_Outcomes |  | outcome_code references Research_Outcomes(outcome_code), project_id references Projects(project_id) | 15 |
| Project_Staff | staff_id | role_code references Staff_Roles(role_code), project_id references Projects(project_id) | 15 |
| Projects | project_id | organisation_id references Organisations(organisation_id) | 15 |
| Research_Outcomes | outcome_code |  | 2 |
| Research_Staff | staff_id | employer_organisation_id references Organisations(organisation_id) | 15 |
| Staff_Roles | role_code |  | 2 |
| Tasks | task_id | project_id references Projects(project_id) | 15 |
