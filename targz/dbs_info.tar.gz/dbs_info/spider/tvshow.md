| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Cartoon | id | Channel references TV_Channel(id) | 12 |
| TV_Channel | id |  | 15 |
| TV_series | id | Channel references TV_Channel(id) | 12 |
