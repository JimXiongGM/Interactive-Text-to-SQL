| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| chip_model | Model_name |  | 14 |
| phone | Hardware_Model_name | chip_model references chip_model(Model_name), screen_mode references screen_mode(Graphics_mode) | 8 |
| screen_mode | Graphics_mode |  | 7 |
