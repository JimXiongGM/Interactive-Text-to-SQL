| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Addresses | address_id |  | 15 |
| Forms | form_id | service_id references Services(service_id) | 6 |
| Individuals | individual_id |  | 15 |
| Organization_Contact_Individuals | individual_id | individual_id references Individuals(individual_id), organization_id references Organizations(organization_id) | 15 |
| Organizations | organization_id |  | 5 |
| Parties | party_id |  | 15 |
| Party_Addresses | party_id | party_id references Parties(party_id), address_id references Addresses(address_id) | 15 |
| Party_Forms | party_id | form_id references Forms(form_id), party_id references Parties(party_id) | 13 |
| Party_Services |  | customer_id references Parties(party_id), service_id references Services(service_id) | 15 |
| Services | service_id |  | 15 |
