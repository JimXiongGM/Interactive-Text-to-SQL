| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| church | Church_ID |  | 9 |
| people | People_ID |  | 12 |
| wedding | Church_ID | Female_ID references people(People_ID), Male_ID references people(People_ID), Church_ID references church(Church_ID) | 4 |
