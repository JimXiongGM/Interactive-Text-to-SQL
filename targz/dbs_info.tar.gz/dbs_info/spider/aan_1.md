| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Affiliation | affiliation_id |  | 2431 |
| Author | author_id |  | 21486 |
| Author_list | paper_id | affiliation_id references Affiliation(affiliation_id), author_id references Author(author_id), paper_id references Paper(paper_id) | 68036 |
| Citation | paper_id | cited_paper_id references Paper(paper_id), paper_id references Paper(paper_id) | 124842 |
| Paper | paper_id |  | 26112 |
