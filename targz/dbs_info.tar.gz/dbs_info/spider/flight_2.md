| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| airlines | uid | uid references flights(Airline) | 12 |
| airports | AirportCode |  | 100 |
| flights | Airline | DestAirport references airports(AirportCode), SourceAirport references airports(AirportCode) | 1200 |
