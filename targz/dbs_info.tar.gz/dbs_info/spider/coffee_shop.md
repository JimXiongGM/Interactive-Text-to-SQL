| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| happy_hour | HH_ID | Shop_ID references shop(Shop_ID) | 10 |
| happy_hour_member | HH_ID | Member_ID references member(Member_ID) | 6 |
| member | Member_ID |  | 10 |
| shop | Shop_ID |  | 10 |
