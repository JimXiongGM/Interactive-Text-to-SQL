| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| matches |  | winner_id references players(player_id), loser_id references players(player_id) | 278 |
| players | player_id |  | 20662 |
| rankings |  | player_id references players(player_id) | 510437 |
