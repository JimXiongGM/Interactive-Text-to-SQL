| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| All_Documents | Document_ID | Date_Stored references Ref_Calendar(Calendar_Date), Document_Type_Code references Ref_Document_Types(Document_Type_Code) | 15 |
| Document_Locations | Document_ID | Document_ID references All_Documents(Document_ID), Date_in_Locaton_To references Ref_Calendar(Calendar_Date), Date_in_Location_From references Ref_Calendar(Calendar_Date), Location_Code references Ref_Locations(Location_Code) | 15 |
| Documents_to_be_Destroyed | Document_ID | Document_ID references All_Documents(Document_ID), Actual_Destruction_Date references Ref_Calendar(Calendar_Date), Planned_Destruction_Date references Ref_Calendar(Calendar_Date), Destruction_Authorised_by_Employee_ID references Employees(Employee_ID), Destroyed_by_Employee_ID references Employees(Employee_ID) | 11 |
| Employees | Employee_ID | Role_Code references Roles(Role_Code) | 15 |
| Ref_Calendar | Calendar_Date |  | 15 |
| Ref_Document_Types | Document_Type_Code |  | 4 |
| Ref_Locations | Location_Code |  | 5 |
| Roles | Role_Code |  | 5 |
