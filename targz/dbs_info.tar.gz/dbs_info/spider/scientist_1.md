| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| AssignedTo | Scientist | Project references Projects(Code), Scientist references Scientists(SSN) | 12 |
| Projects | Code |  | 14 |
| Scientists | SSN |  | 12 |
