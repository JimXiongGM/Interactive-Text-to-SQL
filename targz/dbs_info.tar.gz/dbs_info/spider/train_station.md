| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| station | Station_ID |  | 12 |
| train | Train_ID |  | 11 |
| train_station | Train_ID | Station_ID references station(Station_ID), Train_ID references train(Train_ID) | 11 |
