| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| city | City_ID |  | 13 |
| hosting_city | Year | Match_ID references match(Match_ID), Host_City references city(City_ID) | 6 |
| match | Match_ID |  | 6 |
| temperature | City_ID | City_ID references city(City_ID) | 8 |
