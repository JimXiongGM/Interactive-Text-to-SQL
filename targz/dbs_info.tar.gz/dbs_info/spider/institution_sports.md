| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Championship | Institution_ID | Institution_ID references institution(Institution_ID) | 4 |
| institution | Institution_ID |  | 5 |
