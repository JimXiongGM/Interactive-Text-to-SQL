| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| actor | aid |  | 0 |
| cast | id | msid references copyright(msid), aid references actor(aid) | 0 |
| classification | id | msid references movie(mid) | 0 |
| company | id |  | 0 |
| copyright | id |  | 0 |
| directed_by | id | did references director(did), msid references copyright(msid) | 0 |
| director | did |  | 0 |
| genre | gid |  | 0 |
| keyword | id |  | 0 |
| made_by | id | pid references producer(pid), msid references copyright(msid) | 0 |
| movie | mid | mid references cast(msid) | 0 |
| producer | pid |  | 0 |
| tags | id | kid references keyword(kid), msid references copyright(msid) | 0 |
| tv_series | sid | sid references cast(msid) | 0 |
| writer | wid |  | 0 |
| written_by |  | wid references writer(wid), msid references copyright(msid) | 0 |
