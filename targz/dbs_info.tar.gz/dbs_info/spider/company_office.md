| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Companies | id |  | 19 |
| Office_locations | building_id | company_id references Companies(id), building_id references buildings(id) | 16 |
| buildings | id |  | 12 |
