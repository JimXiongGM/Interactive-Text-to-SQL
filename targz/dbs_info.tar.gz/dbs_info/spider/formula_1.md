| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| circuits | circuitId |  | 73 |
| constructorResults | constructorResultsId | raceId references races(raceId), constructorId references constructors(constructorId) | 11142 |
| constructorStandings | constructorStandingsId | raceId references races(raceId), constructorId references constructors(constructorId) | 11896 |
| constructors | constructorId |  | 208 |
| driverStandings | driverStandingsId | driverId references drivers(driverId), raceId references races(raceId) | 31726 |
| drivers | driverId |  | 842 |
| lapTimes | raceId | driverId references drivers(driverId), raceId references races(raceId) | 0 |
| pitStops | raceId | driverId references drivers(driverId), raceId references races(raceId) | 0 |
| qualifying | qualifyId | driverId references drivers(driverId), raceId references races(raceId), constructorId references constructors(constructorId) | 7516 |
| races | raceId | circuitId references circuits(circuitId) | 997 |
| results | resultId | driverId references drivers(driverId), raceId references races(raceId), constructorId references constructors(constructorId) | 23777 |
| seasons | year |  | 69 |
| status | statusId |  | 134 |
