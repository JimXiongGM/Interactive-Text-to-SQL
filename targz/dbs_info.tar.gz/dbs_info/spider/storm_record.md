| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| affected_region | Region_id | Storm_ID references storm(Storm_ID), Region_id references region(Region_id) | 6 |
| region | Region_id |  | 13 |
| storm | Storm_ID |  | 10 |
