| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Agencies | agency_id |  | 15 |
| Clients | client_id | agency_id references Agencies(agency_id) | 15 |
| Invoices | invoice_id | client_id references Clients(client_id) | 15 |
| Meetings | meeting_id | client_id references Clients(client_id) | 15 |
| Payments |  | invoice_id references Invoices(invoice_id) | 15 |
| Staff | staff_id |  | 15 |
| Staff_in_Meetings |  | staff_id references Staff(staff_id), meeting_id references Meetings(meeting_id) | 15 |
