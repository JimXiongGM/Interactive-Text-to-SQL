| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Acceptance | Submission_ID | Workshop_ID references workshop(Workshop_ID), Submission_ID references submission(Submission_ID) | 6 |
| submission | Submission_ID |  | 10 |
| workshop | Workshop_ID |  | 6 |
