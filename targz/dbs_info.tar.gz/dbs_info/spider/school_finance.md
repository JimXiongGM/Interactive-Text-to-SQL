| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| School | School_id |  | 8 |
| budget | School_id | School_id references School(School_id) | 8 |
| endowment | endowment_id | School_id references School(School_id) | 11 |
