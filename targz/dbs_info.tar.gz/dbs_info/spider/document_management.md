| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Document_Functional_Areas |  | functional_area_code references Functional_Areas(functional_area_code), document_code references Documents(document_code) | 15 |
| Document_Sections | section_id | document_code references Documents(document_code) | 15 |
| Document_Sections_Images | section_id | image_id references Images(image_id), section_id references Document_Sections(section_id) | 20 |
| Document_Structures | document_structure_code |  | 5 |
| Documents | document_code | document_structure_code references Document_Structures(document_structure_code) | 15 |
| Functional_Areas | functional_area_code |  | 3 |
| Images | image_id |  | 15 |
| Roles | role_code |  | 2 |
| Users | user_id | role_code references Roles(role_code) | 15 |
