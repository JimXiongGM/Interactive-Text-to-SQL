| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| car_makers | Id | Country references countries(CountryId) | 22 |
| car_names | MakeId | Model references model_list(Model) | 406 |
| cars_data | Id | Id references car_names(MakeId) | 406 |
| continents | ContId |  | 5 |
| countries | CountryId | Continent references continents(ContId) | 15 |
| model_list | ModelId | Maker references car_makers(Id) | 36 |
