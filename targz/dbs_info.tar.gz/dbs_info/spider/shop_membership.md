| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| branch | Branch_ID |  | 8 |
| member | Member_ID |  | 10 |
| membership_register_branch | Member_ID | Branch_ID references branch(Branch_ID), Member_ID references member(Member_ID) | 8 |
| purchase | Member_ID | Branch_ID references branch(Branch_ID), Member_ID references member(Member_ID) | 8 |
