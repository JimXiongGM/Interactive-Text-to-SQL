| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Breeds | breed_code |  | 3 |
| Charges | charge_id |  | 3 |
| Dogs | dog_id | owner_id references Owners(owner_id), owner_id references Owners(owner_id), size_code references Sizes(size_code), breed_code references Breeds(breed_code) | 15 |
| Owners | owner_id |  | 15 |
| Professionals | professional_id |  | 15 |
| Sizes | size_code |  | 3 |
| Treatment_Types | treatment_type_code |  | 3 |
| Treatments | treatment_id | dog_id references Dogs(dog_id), professional_id references Professionals(professional_id), treatment_type_code references Treatment_Types(treatment_type_code) | 15 |
