| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Achievements | achievement_id | achievement_type_code references Ref_Achievement_Type(achievement_type_code), student_id references Students(student_id) | 20 |
| Addresses | address_id |  | 15 |
| Behaviour_Monitoring | behaviour_monitoring_id | student_id references Students(student_id) | 15 |
| Classes | class_id | teacher_id references Teachers(teacher_id), student_id references Students(student_id) | 20 |
| Detention | detention_id | detention_type_code references Ref_Detention_Type(detention_type_code), student_id references Students(student_id) | 20 |
| Ref_Achievement_Type | achievement_type_code |  | 2 |
| Ref_Address_Types | address_type_code |  | 2 |
| Ref_Detention_Type | detention_type_code |  | 4 |
| Ref_Event_Types | event_type_code |  | 2 |
| Student_Events | event_id | event_type_code references Ref_Event_Types(event_type_code), student_id references Students(student_id) | 4 |
| Student_Loans | student_loan_id | student_id references Students(student_id) | 20 |
| Students | student_id |  | 15 |
| Students_Addresses | student_address_id | address_type_code references Ref_Address_Types(address_type_code), address_id references Addresses(address_id), student_id references Students(student_id) | 15 |
| Teachers | teacher_id |  | 15 |
| Transcripts | transcript_id | student_id references Students(student_id) | 15 |
