| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Album | AlbumId | ArtistId references Artist(ArtistId) | 347 |
| Artist | ArtistId |  | 275 |
| Customer | CustomerId | SupportRepId references Employee(EmployeeId) | 59 |
| Employee | EmployeeId | ReportsTo references Employee(EmployeeId) | 8 |
| Genre | GenreId |  | 25 |
| Invoice | InvoiceId | CustomerId references Customer(CustomerId) | 412 |
| InvoiceLine | InvoiceLineId | TrackId references Track(TrackId), InvoiceId references Invoice(InvoiceId) | 2240 |
| MediaType | MediaTypeId |  | 5 |
| Playlist | PlaylistId |  | 18 |
| PlaylistTrack | PlaylistId | TrackId references Track(TrackId), PlaylistId references Playlist(PlaylistId) | 8715 |
| Track | TrackId | MediaTypeId references MediaType(MediaTypeId), GenreId references Genre(GenreId), AlbumId references Album(AlbumId) | 3503 |
