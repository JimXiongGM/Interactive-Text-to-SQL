| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Has_Pet |  | StuID references Student(StuID), PetID references Pets(PetID) | 3 |
| Pets | PetID |  | 3 |
| Student | StuID |  | 34 |
