| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Benefits_Overpayments | council_tax_id | cmi_cross_ref_id references CMI_Cross_References(cmi_cross_ref_id) | 4 |
| Business_Rates | business_rates_id | cmi_cross_ref_id references CMI_Cross_References(cmi_cross_ref_id) | 3 |
| CMI_Cross_References | cmi_cross_ref_id | master_customer_id references Customer_Master_Index(master_customer_id) | 21 |
| Council_Tax | council_tax_id | cmi_cross_ref_id references CMI_Cross_References(cmi_cross_ref_id) | 6 |
| Customer_Master_Index | master_customer_id |  | 9 |
| Electoral_Register | electoral_register_id | cmi_cross_ref_id references CMI_Cross_References(cmi_cross_ref_id) | 6 |
| Parking_Fines | council_tax_id | cmi_cross_ref_id references CMI_Cross_References(cmi_cross_ref_id) | 2 |
| Rent_Arrears | council_tax_id | cmi_cross_ref_id references CMI_Cross_References(cmi_cross_ref_id) | 4 |
