| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| actor | actor_id |  | 200 |
| address | address_id | city_id references city(city_id) | 603 |
| category | category_id |  | 16 |
| city | city_id | country_id references country(country_id) | 600 |
| country | country_id |  | 109 |
| customer | customer_id | store_id references store(store_id), address_id references address(address_id) | 599 |
| film | film_id | original_language_id references language(language_id), language_id references language(language_id) | 1000 |
| film_actor | actor_id | film_id references film(film_id), actor_id references actor(actor_id) | 5462 |
| film_category | film_id | category_id references category(category_id), film_id references film(film_id) | 1000 |
| film_text | film_id |  | 0 |
| inventory | inventory_id | film_id references film(film_id), store_id references store(store_id) | 4581 |
| language | language_id |  | 0 |
| payment | payment_id | staff_id references staff(staff_id), customer_id references customer(customer_id), rental_id references rental(rental_id) | 16049 |
| rental | rental_id | customer_id references customer(customer_id), inventory_id references inventory(inventory_id), staff_id references staff(staff_id) | 16044 |
| staff | staff_id | address_id references address(address_id) | 0 |
| store | store_id | address_id references address(address_id), manager_staff_id references staff(staff_id) | 0 |
