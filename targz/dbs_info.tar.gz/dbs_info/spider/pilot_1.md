| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Hangar | plane_name |  | 4 |
| PilotSkills | pilot_name | plane_name references Hangar(plane_name) | 13 |
