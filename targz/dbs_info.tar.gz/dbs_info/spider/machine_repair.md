| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| machine | Machine_ID |  | 9 |
| repair | repair_ID |  | 9 |
| repair_assignment | technician_id | Machine_ID references machine(Machine_ID), repair_ID references repair(repair_ID), technician_id references technician(technician_id) | 9 |
| technician | technician_id |  | 10 |
