| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Addresses | Address_ID |  | 15 |
| Agreements | Document_ID | Event_ID references Events(Event_ID) | 15 |
| Assets | Asset_ID |  | 3 |
| Assets_in_Events | Asset_ID | Event_ID references Events(Event_ID), Event_ID references Events(Event_ID) | 12 |
| Channels | Channel_ID |  | 15 |
| Events | Event_ID | Finance_ID references Finances(Finance_ID), Address_ID references Addresses(Address_ID), Location_ID references Locations(Location_ID) | 15 |
| Finances | Finance_ID |  | 15 |
| Locations | Location_ID |  | 15 |
| Parties | Party_ID |  | 7 |
| Parties_in_Events | Party_ID | Event_ID references Events(Event_ID), Party_ID references Parties(Party_ID) | 15 |
| Products | Product_ID |  | 15 |
| Products_in_Events | Product_in_Event_ID | Product_ID references Products(Product_ID), Event_ID references Events(Event_ID) | 15 |
