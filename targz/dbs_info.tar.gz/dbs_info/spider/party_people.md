| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| member | Member_ID | Party_ID references party(Party_ID) | 15 |
| party | Party_ID | Region_ID references region(Region_ID) | 5 |
| party_events | Event_ID | Member_in_charge_ID references member(Member_ID), Party_ID references party(Party_ID) | 8 |
| region | Region_ID |  | 5 |
