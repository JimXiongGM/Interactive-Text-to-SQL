| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Reservations | Code | Room references Rooms(RoomId) | 600 |
| Rooms | RoomId |  | 10 |
