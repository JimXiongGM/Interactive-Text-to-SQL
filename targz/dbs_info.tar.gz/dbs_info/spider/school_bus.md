| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| driver | Driver_ID |  | 12 |
| school | School_ID |  | 7 |
| school_bus | School_ID | Driver_ID references driver(Driver_ID), School_ID references school(School_ID) | 5 |
