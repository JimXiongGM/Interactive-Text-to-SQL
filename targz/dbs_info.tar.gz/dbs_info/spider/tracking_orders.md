| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Customers | customer_id |  | 15 |
| Invoices | invoice_number |  | 15 |
| Order_Items | order_item_id | product_id references Products(product_id), order_id references Orders(order_id) | 15 |
| Orders | order_id | customer_id references Customers(customer_id) | 15 |
| Products | product_id |  | 15 |
| Shipment_Items |  | shipment_id references Shipments(shipment_id), order_item_id references Order_Items(order_item_id) | 15 |
| Shipments | shipment_id | invoice_number references Invoices(invoice_number), order_id references Orders(order_id) | 15 |
