| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Addresses | address_id |  | 10 |
| Circulation_History | document_id | employee_id references Employees(employee_id), document_id references Draft_Copies(document_id), draft_number references Draft_Copies(draft_number), copy_number references Draft_Copies(copy_number) | 4 |
| Document_Drafts | document_id | document_id references Documents(document_id) | 15 |
| Documents | document_id | shipping_agent_code references Ref_Shipping_Agents(shipping_agent_code), document_status_code references Ref_Document_Status(document_status_code), document_type_code references Ref_Document_Types(document_type_code) | 15 |
| Documents_Mailed | document_id | mailed_to_address_id references Addresses(address_id), document_id references Documents(document_id) | 14 |
| Draft_Copies | document_id | document_id references Document_Drafts(document_id), draft_number references Document_Drafts(draft_number) | 8 |
| Employees | employee_id | role_code references Roles(role_code) | 6 |
| Ref_Document_Status | document_status_code |  | 3 |
| Ref_Document_Types | document_type_code |  | 3 |
| Ref_Shipping_Agents | shipping_agent_code |  | 5 |
| Roles | role_code |  | 4 |
