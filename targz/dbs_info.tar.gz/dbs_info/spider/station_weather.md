| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| route | train_id | station_id references station(id), train_id references train(id) | 18 |
| station | id |  | 11 |
| train | id |  | 11 |
| weekly_weather | station_id | station_id references station(id) | 16 |
