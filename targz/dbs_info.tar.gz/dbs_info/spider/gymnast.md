| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| gymnast | Gymnast_ID | Gymnast_ID references people(People_ID) | 7 |
| people | People_ID |  | 10 |
