| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| broadcast | Channel_ID | Program_ID references program(Program_ID), Channel_ID references channel(Channel_ID) | 11 |
| broadcast_share | Channel_ID | Program_ID references program(Program_ID), Channel_ID references channel(Channel_ID) | 9 |
| channel | Channel_ID |  | 10 |
| program | Program_ID |  | 5 |
