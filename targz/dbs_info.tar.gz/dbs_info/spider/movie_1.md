| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Movie | mID |  | 8 |
| Rating |  | rID references Reviewer(rID), mID references Movie(mID) | 14 |
| Reviewer | rID |  | 8 |
