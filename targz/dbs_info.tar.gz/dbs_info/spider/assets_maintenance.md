| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Asset_Parts |  | asset_id references Assets(asset_id), part_id references Parts(part_id) | 15 |
| Assets | asset_id | supplier_company_id references Third_Party_Companies(company_id), maintenance_contract_id references Maintenance_Contracts(maintenance_contract_id) | 15 |
| Engineer_Skills |  | skill_id references Skills(skill_id), engineer_id references Maintenance_Engineers(engineer_id) | 20 |
| Engineer_Visits | engineer_visit_id | contact_staff_id references Staff(staff_id), engineer_id references Maintenance_Engineers(engineer_id), fault_log_entry_id references Fault_Log(fault_log_entry_id) | 15 |
| Fault_Log | fault_log_entry_id | recorded_by_staff_id references Staff(staff_id), asset_id references Assets(asset_id) | 15 |
| Fault_Log_Parts |  | fault_log_entry_id references Fault_Log(fault_log_entry_id), part_fault_id references Part_Faults(part_fault_id) | 15 |
| Maintenance_Contracts | maintenance_contract_id | maintenance_contract_company_id references Third_Party_Companies(company_id) | 15 |
| Maintenance_Engineers | engineer_id | company_id references Third_Party_Companies(company_id) | 15 |
| Part_Faults | part_fault_id | part_id references Parts(part_id) | 15 |
| Parts | part_id |  | 3 |
| Skills | skill_id |  | 3 |
| Skills_Required_To_Fix |  | skill_id references Skills(skill_id), part_fault_id references Part_Faults(part_fault_id) | 15 |
| Staff | staff_id |  | 15 |
| Third_Party_Companies | company_id |  | 15 |
