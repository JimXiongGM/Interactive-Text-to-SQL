| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Artists | artistID |  | 5 |
| Paintings | paintingID | painterID references Artists(artistID) | 14 |
| Sculptures | sculptureID | sculptorID references Artists(artistID) | 4 |
