| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| country | Country_ID |  | 3 |
| roller_coaster | Roller_Coaster_ID | Country_ID references country(Country_ID) | 6 |
