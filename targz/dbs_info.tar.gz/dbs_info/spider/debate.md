| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| debate | Debate_ID |  | 6 |
| debate_people | Debate_ID | Negative references people(People_ID), Affirmative references people(People_ID), Debate_ID references debate(Debate_ID) | 5 |
| people | People_ID |  | 10 |
