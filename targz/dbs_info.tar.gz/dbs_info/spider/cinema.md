| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| cinema | Cinema_ID |  | 10 |
| film | Film_ID |  | 5 |
| schedule | Cinema_ID | Cinema_ID references cinema(Cinema_ID), Film_ID references film(Film_ID) | 7 |
