| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| climber | Climber_ID | Mountain_ID references mountain(Mountain_ID) | 10 |
| mountain | Mountain_ID |  | 7 |
