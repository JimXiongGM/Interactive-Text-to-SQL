| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| business | bid |  | 0 |
| category | id | business_id references business(business_id) | 0 |
| checkin | cid | business_id references business(business_id) | 0 |
| neighbourhood | id | business_id references business(business_id) | 0 |
| review | rid | user_id references user(user_id), business_id references business(business_id) | 0 |
| tip | tip_id | user_id references user(user_id), business_id references business(business_id) | 0 |
| user | uid |  | 0 |
