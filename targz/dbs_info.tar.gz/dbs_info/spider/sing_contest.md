| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| participants | id |  | 5 |
| performance_score | participant_id | songs_id references songs(id), participant_id references participants(id) | 10 |
| songs | id |  | 25 |
