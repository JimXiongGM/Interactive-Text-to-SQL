| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Restaurant | ResID |  | 2 |
| Restaurant_Type | ResTypeID |  | 2 |
| Student | StuID |  | 34 |
| Type_Of_Restaurant |  | ResTypeID references Restaurant_Type(ResTypeID), ResID references Restaurant(ResID) | 2 |
| Visits_Restaurant |  | ResID references Restaurant(ResID), StuID references Student(StuID) | 2 |
