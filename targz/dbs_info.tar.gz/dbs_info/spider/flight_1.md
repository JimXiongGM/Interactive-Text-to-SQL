| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| aircraft | aid |  | 16 |
| certificate | eid | aid references aircraft(aid), eid references employee(eid) | 69 |
| employee | eid |  | 31 |
| flight | flno | aid references aircraft(aid) | 10 |
