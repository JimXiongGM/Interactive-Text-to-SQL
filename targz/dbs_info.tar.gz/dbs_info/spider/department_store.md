| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Addresses | address_id |  | 15 |
| Customer_Addresses | customer_id | customer_id references Customers(customer_id), address_id references Addresses(address_id) | 15 |
| Customer_Orders | order_id | customer_id references Customers(customer_id) | 15 |
| Customers | customer_id |  | 15 |
| Department_Store_Chain | dept_store_chain_id |  | 4 |
| Department_Stores | dept_store_id | dept_store_chain_id references Department_Store_Chain(dept_store_chain_id) | 15 |
| Departments | department_id | dept_store_id references Department_Stores(dept_store_id) | 5 |
| Order_Items | order_item_id | product_id references Products(product_id), order_id references Customer_Orders(order_id) | 15 |
| Product_Suppliers | product_id | product_id references Products(product_id), supplier_id references Suppliers(supplier_id) | 15 |
| Products | product_id |  | 15 |
| Staff | staff_id |  | 15 |
| Staff_Department_Assignments | staff_id | staff_id references Staff(staff_id), department_id references Departments(department_id) | 15 |
| Supplier_Addresses | supplier_id | supplier_id references Suppliers(supplier_id), address_id references Addresses(address_id) | 4 |
| Suppliers | supplier_id |  | 4 |
