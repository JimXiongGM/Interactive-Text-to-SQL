| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Claim_Headers | Claim_Header_ID | Policy_ID references Policies(Policy_ID) | 15 |
| Claims_Documents | Claim_ID | Created_by_Staff_ID references Staff(Staff_ID), Claim_ID references Claim_Headers(Claim_Header_ID) | 14 |
| Claims_Processing | Claim_Processing_ID | Staff_ID references Staff(Staff_ID), Claim_ID references Claim_Headers(Claim_Header_ID) | 15 |
| Claims_Processing_Stages | Claim_Stage_ID |  | 2 |
| Customers | Customer_ID |  | 15 |
| Policies | Policy_ID | Customer_ID references Customers(Customer_ID) | 15 |
| Staff | Staff_ID |  | 15 |
