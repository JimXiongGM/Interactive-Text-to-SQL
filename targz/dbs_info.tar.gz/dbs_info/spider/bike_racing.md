| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| bike | id |  | 6 |
| cyclist | id |  | 8 |
| cyclists_own_bikes | cyclist_id | bike_id references bike(id), cyclist_id references cyclist(id) | 14 |
