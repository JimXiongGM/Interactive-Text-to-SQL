| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Author | idAuthor |  | 7 |
| Author_Book | ISBN | Author references Author(idAuthorA), ISBN references Book(ISBN) | 7 |
| Book | ISBN |  | 7 |
| Books_Order | ISBN | IdOrder references Orders(IdOrder), ISBN references Book(ISBN) | 11 |
| Client | IdClient |  | 6 |
| Orders | IdOrder | IdClient references Client(None) | 6 |
