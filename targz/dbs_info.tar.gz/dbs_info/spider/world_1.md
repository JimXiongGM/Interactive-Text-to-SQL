| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| city | ID | CountryCode references country(Code) | 4079 |
| country | Code |  | 239 |
| countrylanguage | CountryCode | CountryCode references country(Code) | 984 |
