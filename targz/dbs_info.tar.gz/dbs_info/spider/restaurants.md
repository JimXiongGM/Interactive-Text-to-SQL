| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| GEOGRAPHIC | CITY_NAME |  | 0 |
| LOCATION | RESTAURANT_ID | RESTAURANT_ID references RESTAURANT(RESTAURANT_ID), CITY_NAME references GEOGRAPHIC(CITY_NAME) | 0 |
| RESTAURANT | ID | CITY_NAME references GEOGRAPHIC(CITY_NAME) | 0 |
