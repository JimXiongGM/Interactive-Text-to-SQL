| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| concert | concert_ID | Stadium_ID references stadium(Stadium_ID) | 6 |
| singer | Singer_ID |  | 6 |
| singer_in_concert | concert_ID | Singer_ID references singer(Singer_ID), concert_ID references concert(concert_ID) | 10 |
| stadium | Stadium_ID |  | 9 |
