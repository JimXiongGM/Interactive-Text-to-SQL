| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Customer_Event_Notes | Customer_Event_Note_ID | Customer_Event_ID references Customer_Events(Customer_Event_ID) | 13 |
| Customer_Events | Customer_Event_ID | resident_id references Residents(resident_id), property_id references Residents(property_id), date_moved_in references Residents(date_moved_in), customer_id references Customers(customer_id), thing_id references Things(thing_id) | 13 |
| Customers | customer_id |  | 15 |
| Organizations | organization_id |  | 3 |
| Properties | property_id |  | 15 |
| Residents | resident_id | property_id references Properties(property_id) | 15 |
| Residents_Services | resident_id | resident_id references Residents(resident_id), property_id references Residents(property_id), date_moved_in references Residents(date_moved_in), service_id references Services(service_id) | 11 |
| Services | service_id | organization_id references Organizations(organization_id) | 15 |
| Things | thing_id | organization_id references Organizations(organization_id) | 15 |
| Timed_Locations_of_Things | thing_id | thing_id references Things(thing_id) | 15 |
| Timed_Status_of_Things | thing_id | thing_id references Things(thing_id) | 18 |
