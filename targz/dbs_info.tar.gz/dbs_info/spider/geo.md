| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| border_info | border | border references state(state_name), state_name references state(state_name) | 0 |
| city | city_name | state_name references state(state_name) | 0 |
| highlow | state_name | state_name references state(state_name) | 0 |
| lake |  |  | 0 |
| mountain | mountain_name | state_name references state(state_name) | 0 |
| river | river_name | traverse references state(state_name) | 0 |
| state | state_name |  | 0 |
