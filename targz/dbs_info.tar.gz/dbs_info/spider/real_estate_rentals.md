| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Addresses | address_id |  | 15 |
| Features | feature_id |  | 5 |
| Properties | property_id | property_type_code references Ref_Property_Types(property_type_code), property_address_id references Addresses(address_id), owner_user_id references Users(user_id) | 15 |
| Property_Features |  | property_id references Properties(property_id), feature_id references Features(feature_id) | 15 |
| Property_Photos |  | property_id references Properties(property_id) | 15 |
| Ref_Age_Categories | age_category_code |  | 3 |
| Ref_Property_Types | property_type_code |  | 3 |
| Ref_Room_Types | room_type_code |  | 4 |
| Ref_User_Categories | user_category_code |  | 3 |
| Rooms |  | room_type_code references Ref_Room_Types(room_type_code), property_id references Properties(property_id) | 15 |
| User_Property_History |  | property_id references Properties(property_id), user_id references Users(user_id) | 15 |
| User_Searches |  | user_id references Users(user_id) | 15 |
| Users | user_id | user_category_code references Ref_User_Categories(user_category_code) | 15 |
