| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Addresses | address_id |  | 15 |
| Candidate_Assessments | candidate_id | candidate_id references Candidates(candidate_id) | 5 |
| Candidates | candidate_id | candidate_id references People(person_id) | 8 |
| Courses | course_id |  | 6 |
| People | person_id |  | 8 |
| People_Addresses | person_address_id | address_id references Addresses(address_id), person_id references People(person_id) | 8 |
| Student_Course_Attendance | student_id | student_id references Student_Course_Registrations(student_id), course_id references Student_Course_Registrations(course_id) | 8 |
| Student_Course_Registrations | student_id | course_id references Courses(course_id), student_id references Students(student_id) | 9 |
| Students | student_id | student_id references People(person_id) | 8 |
