| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| driver | Driver_ID |  | 4 |
| vehicle | Vehicle_ID |  | 8 |
| vehicle_driver | Driver_ID | Vehicle_ID references vehicle(Vehicle_ID), Driver_ID references driver(Driver_ID) | 11 |
