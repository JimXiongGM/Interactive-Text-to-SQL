| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Complaints |  | customer_id references Customers(customer_id), product_id references Products(product_id), staff_id references Staff(staff_id) | 12 |
| Customers | customer_id |  | 8 |
| Products | product_id |  | 4 |
| Staff | staff_id |  | 7 |
