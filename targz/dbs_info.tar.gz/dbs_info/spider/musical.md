| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| actor | Actor_ID | Musical_ID references musical(Musical_ID) | 9 |
| musical | Musical_ID |  | 7 |
