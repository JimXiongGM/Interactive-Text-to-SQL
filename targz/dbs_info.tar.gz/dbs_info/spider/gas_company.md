| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| company | Company_ID |  | 10 |
| gas_station | Station_ID |  | 11 |
| station_company | Station_ID | Company_ID references company(Company_ID), Station_ID references gas_station(Station_ID) | 6 |
