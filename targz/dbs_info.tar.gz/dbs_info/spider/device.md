| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| device | Device_ID |  | 6 |
| shop | Shop_ID |  | 12 |
| stock | Shop_ID | Device_ID references device(Device_ID), Shop_ID references shop(Shop_ID) | 8 |
