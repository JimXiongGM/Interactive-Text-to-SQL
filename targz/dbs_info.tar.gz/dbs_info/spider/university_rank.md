| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| major | Major_ID |  | 5 |
| major_ranking | Rank | Major_ID references major(Major_ID), University_ID references university(University_ID) | 8 |
| overall_ranking | University_ID | University_ID references university(University_ID) | 13 |
| university | University_ID |  | 13 |
