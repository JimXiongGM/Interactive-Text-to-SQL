| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| item | i_id |  | 8 |
| review | a_id | i_id references item(i_id), u_id references useracct(u_id) | 7 |
| trust |  | target_u_id references useracct(u_id), source_u_id references useracct(u_id) | 9 |
| useracct | u_id |  | 7 |
