| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Allergy_Type | Allergy |  | 14 |
| Has_Allergy |  | Allergy references Allergy_Type(Allergy), StuID references Student(StuID) | 59 |
| Student | StuID |  | 34 |
