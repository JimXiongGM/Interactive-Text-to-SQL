| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Course_Authors_and_Tutors | author_id |  | 15 |
| Courses | course_id | subject_id references Subjects(subject_id), author_id references Course_Authors_and_Tutors(author_id) | 15 |
| Student_Course_Enrolment | registration_id | student_id references Students(student_id), course_id references Courses(course_id) | 20 |
| Student_Tests_Taken |  | registration_id references Student_Course_Enrolment(registration_id) | 15 |
| Students | student_id |  | 15 |
| Subjects | subject_id |  | 3 |
