| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| aircraft | Aircraft_ID |  | 5 |
| airport | Airport_ID |  | 10 |
| airport_aircraft | Airport_ID | Aircraft_ID references aircraft(Aircraft_ID), Airport_ID references airport(Airport_ID) | 4 |
| match | Round | Winning_Pilot references pilot(Pilot_Id), Winning_Aircraft references aircraft(Aircraft_ID) | 7 |
| pilot | Pilot_Id |  | 12 |
