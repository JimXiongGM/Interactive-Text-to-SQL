| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Client | AccountNumber |  | 11 |
| Employee | EmployeeID |  | 8 |
| Has_Clearance | Employee | Planet references Planet(PlanetID), Employee references Employee(EmployeeID) | 7 |
| Package | Shipment | Recipient references Client(AccountNumber), Sender references Client(AccountNumber), Shipment references Shipment(ShipmentID) | 9 |
| Planet | PlanetID |  | 9 |
| Shipment | ShipmentID | Planet references Planet(PlanetID), Manager references Employee(EmployeeID) | 5 |
