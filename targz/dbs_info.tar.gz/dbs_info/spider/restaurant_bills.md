| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| branch | Branch_ID |  | 10 |
| customer | Customer_ID |  | 8 |
| customer_order | Customer_ID | Branch_ID references branch(Branch_ID), Customer_ID references customer(Customer_ID) | 6 |
