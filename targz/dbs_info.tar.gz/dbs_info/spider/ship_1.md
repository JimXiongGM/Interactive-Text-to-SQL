| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Ship | Ship_ID |  | 9 |
| captain | Captain_ID | Ship_ID references Ship(Ship_ID) | 7 |
