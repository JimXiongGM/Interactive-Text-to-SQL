| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| museum | Museum_ID |  | 8 |
| visit | Museum_ID | visitor_ID references visitor(ID), Museum_ID references museum(Museum_ID) | 6 |
| visitor | ID |  | 6 |
