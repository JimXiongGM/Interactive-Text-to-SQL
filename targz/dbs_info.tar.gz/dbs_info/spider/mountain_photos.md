| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| camera_lens | id |  | 11 |
| mountain | id |  | 23 |
| photos | id | mountain_id references mountain(id), camera_lens_id references camera_lens(id) | 10 |
