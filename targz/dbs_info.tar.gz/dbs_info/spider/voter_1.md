| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| AREA_CODE_STATE | area_code |  | 305 |
| CONTESTANTS | contestant_number |  | 11 |
| VOTES | vote_id | contestant_number references CONTESTANTS(contestant_number), state references AREA_CODE_STATE(state) | 4 |
