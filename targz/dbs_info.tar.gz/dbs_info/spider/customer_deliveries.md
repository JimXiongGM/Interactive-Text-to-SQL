| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Actual_Order_Products |  | actual_order_id references Actual_Orders(actual_order_id), product_id references Products(product_id) | 15 |
| Actual_Orders | actual_order_id | regular_order_id references Regular_Orders(regular_order_id) | 15 |
| Addresses | address_id |  | 15 |
| Customer_Addresses |  | address_id references Addresses(address_id), customer_id references Customers(customer_id) | 15 |
| Customers | customer_id |  | 15 |
| Delivery_Route_Locations | location_code | route_id references Delivery_Routes(route_id), location_address_id references Addresses(address_id) | 15 |
| Delivery_Routes | route_id |  | 15 |
| Employees | employee_id | employee_address_id references Addresses(address_id) | 15 |
| Order_Deliveries |  | driver_employee_id references Employees(employee_id), location_code references Delivery_Route_Locations(location_code), actual_order_id references Actual_Orders(actual_order_id), truck_id references Trucks(truck_id) | 15 |
| Products | product_id |  | 6 |
| Regular_Order_Products |  | regular_order_id references Regular_Orders(regular_order_id), product_id references Products(product_id) | 15 |
| Regular_Orders | regular_order_id | distributer_id references Customers(customer_id) | 15 |
| Trucks | truck_id |  | 15 |
