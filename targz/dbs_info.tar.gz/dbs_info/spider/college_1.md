| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| CLASS | CLASS_CODE | PROF_NUM references EMPLOYEE(EMP_NUM), CRS_CODE references COURSE(CRS_CODE) | 13 |
| COURSE | CRS_CODE | DEPT_CODE references DEPARTMENT(DEPT_CODE) | 6 |
| DEPARTMENT | DEPT_CODE | EMP_NUM references EMPLOYEE(EMP_NUM) | 11 |
| EMPLOYEE | EMP_NUM |  | 37 |
| ENROLL |  | STU_NUM references STUDENT(STU_NUM), CLASS_CODE references CLASS(CLASS_CODE) | 6 |
| PROFESSOR |  | DEPT_CODE references DEPARTMENT(DEPT_CODE), EMP_NUM references EMPLOYEE(EMP_NUM) | 22 |
| STUDENT | STU_NUM | DEPT_CODE references DEPARTMENT(DEPT_CODE) | 8 |
