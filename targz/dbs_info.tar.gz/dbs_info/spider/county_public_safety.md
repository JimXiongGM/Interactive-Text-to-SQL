| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| city | City_ID | County_ID references county_public_safety(County_ID) | 17 |
| county_public_safety | County_ID |  | 6 |
