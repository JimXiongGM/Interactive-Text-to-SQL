| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| country | Country_Id |  | 6 |
| driver | Driver_ID | Country references country(Country_ID) | 10 |
| team | Team_ID |  | 12 |
| team_driver | Team_ID | Driver_ID references driver(Driver_ID), Team_ID references team(Team_ID) | 10 |
