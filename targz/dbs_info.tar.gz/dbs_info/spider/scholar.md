| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| author | authorId |  | 0 |
| cite | citingPaperId | citingPaperId references paper(paperId), citedPaperId references paper(paperId) | 0 |
| dataset | datasetId |  | 0 |
| journal | journalId |  | 0 |
| keyphrase | keyphraseId |  | 0 |
| paper | paperId | venueId references venue(venueId), journalId references journal(journalId) | 0 |
| paperKeyphrase | keyphraseId | keyphraseId references keyphrase(keyphraseId), paperId references paper(paperId) | 0 |
| paperdataset | paperId | paperId references paper(paperid), datasetId references dataset(datasetid) | 0 |
| venue | venueId |  | 0 |
| writes | paperId | authorId references author(authorId), paperId references paper(paperId) | 0 |
