| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| district | District_ID |  | 5 |
| spokesman | Spokesman_ID |  | 12 |
| spokesman_district | Spokesman_ID | District_ID references district(District_ID), Spokesman_ID references spokesman(Spokesman_ID) | 6 |
