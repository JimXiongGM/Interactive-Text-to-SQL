| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| employee | Employee_ID |  | 10 |
| evaluation | Employee_ID | Employee_ID references employee(Employee_ID) | 6 |
| hiring | Employee_ID | Employee_ID references employee(Employee_ID), Shop_ID references shop(Shop_ID) | 7 |
| shop | Shop_ID |  | 9 |
