| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| film | Film_ID |  | 13 |
| film_market_estimation | Estimation_ID | Market_ID references market(Market_ID), Film_ID references film(Film_ID) | 9 |
| market | Market_ID |  | 6 |
