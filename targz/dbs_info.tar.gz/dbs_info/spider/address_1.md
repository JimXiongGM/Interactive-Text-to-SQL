| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| City | city_code |  | 31 |
| Direct_distance |  | city2_code references City(city_code), city1_code references City(city_code) | 119 |
| Student | StuID | city_code references City(city_code) | 34 |
