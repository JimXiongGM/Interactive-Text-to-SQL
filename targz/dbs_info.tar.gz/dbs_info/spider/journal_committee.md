| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| editor | Editor_ID |  | 9 |
| journal | Journal_ID |  | 16 |
| journal_committee | Editor_ID | Journal_ID references journal(Journal_ID), Editor_ID references editor(Editor_ID) | 7 |
