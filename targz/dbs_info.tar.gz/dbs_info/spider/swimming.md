| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| event | ID | Stadium_ID references stadium(ID) | 6 |
| record | Swimmer_ID | Swimmer_ID references swimmer(ID), Event_ID references event(ID) | 13 |
| stadium | ID |  | 10 |
| swimmer | ID |  | 8 |
