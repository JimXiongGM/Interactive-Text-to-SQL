| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| market | Market_ID |  | 6 |
| phone | Phone_ID |  | 5 |
| phone_market | Market_ID | Phone_ID references phone(Phone_ID), Market_ID references market(Market_ID) | 6 |
