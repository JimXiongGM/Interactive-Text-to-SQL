| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Claims | Claim_ID | Policy_ID references Customer_Policies(Policy_ID) | 15 |
| Customer_Policies | Policy_ID | Customer_ID references Customers(Customer_ID) | 15 |
| Customers | Customer_ID |  | 15 |
| Payments | Payment_ID | Settlement_ID references Settlements(Settlement_ID) | 15 |
| Settlements | Settlement_ID | Claim_ID references Claims(Claim_ID) | 15 |
