| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Authors | author_name |  | 20 |
| Business_Processes | process_id |  | 1 |
| Documents | document_id | author_name references Authors(author_name) | 15 |
| Documents_Processes | document_id | process_status_code references Process_Status(process_status_code), process_outcome_code references Process_Outcomes(process_outcome_code), process_id references Business_Processes(process_id), document_id references Documents(document_id) | 10 |
| Process_Outcomes | process_outcome_code |  | 3 |
| Process_Status | process_status_code |  | 2 |
| Ref_Staff_Roles | staff_role_code |  | 5 |
| Staff | staff_id |  | 8 |
| Staff_in_Processes | document_id | staff_role_code references Ref_Staff_Roles(staff_role_code), document_id references Documents_Processes(document_id), process_id references Documents_Processes(process_id), staff_id references Staff(staff_id) | 13 |
