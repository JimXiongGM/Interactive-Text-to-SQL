| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| district | District_ID |  | 15 |
| product | product_id |  | 6 |
| store | Store_ID |  | 5 |
| store_district | Store_ID | District_ID references district(District_ID), Store_ID references store(Store_ID) | 5 |
| store_product | Store_ID | Product_ID references product(Product_ID), Store_ID references store(Store_ID) | 15 |
