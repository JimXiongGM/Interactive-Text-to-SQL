| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| station | id |  | 70 |
| status |  | station_id references station(id) | 8487 |
| trip | id | start_station_id references station(id), zip_code references weather(zip_code) | 9959 |
| weather |  |  | 3665 |
