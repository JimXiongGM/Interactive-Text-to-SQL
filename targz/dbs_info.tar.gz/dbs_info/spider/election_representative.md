| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| election | Election_ID | Representative_ID references representative(Representative_ID) | 5 |
| representative | Representative_ID |  | 7 |
