| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| game | Game_ID | Platform_ID references platform(Platform_ID) | 9 |
| game_player | Player_ID | Game_ID references game(Game_ID), Player_ID references player(Player_ID) | 10 |
| platform | Platform_ID |  | 4 |
| player | Player_ID |  | 21 |
