| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| host | Host_ID |  | 10 |
| party | Party_ID |  | 8 |
| party_host | Party_ID | Party_ID references party(Party_ID), Host_ID references host(Host_ID) | 6 |
