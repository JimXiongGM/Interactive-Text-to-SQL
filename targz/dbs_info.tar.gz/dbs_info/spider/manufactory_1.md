| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Manufacturers | Code |  | 6 |
| Products | Code | Manufacturer references Manufacturers(Code) | 11 |
