| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Elimination | Elimination_ID | Wrestler_ID references wrestler(Wrestler_ID) | 6 |
| wrestler | Wrestler_ID |  | 10 |
