| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Club | ClubID |  | 4 |
| Member_of_club |  | ClubID references Club(ClubID), StuID references Student(StuID) | 4 |
| Student | StuID |  | 34 |
