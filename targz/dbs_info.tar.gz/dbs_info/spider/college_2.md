| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| advisor | s_ID | s_ID references student(ID), i_ID references instructor(ID) | 2000 |
| classroom | building |  | 30 |
| course | course_id | dept_name references department(dept_name) | 200 |
| department | dept_name |  | 20 |
| instructor | ID | dept_name references department(dept_name) | 50 |
| prereq | course_id | prereq_id references course(course_id), course_id references course(course_id) | 100 |
| section | course_id | building references classroom(building), room_number references classroom(room_number), course_id references course(course_id) | 100 |
| student | ID | dept_name references department(dept_name) | 2000 |
| takes | ID | ID references student(ID), course_id references section(course_id), sec_id references section(sec_id), semester references section(semester), year references section(year) | 30000 |
| teaches | ID | ID references instructor(ID), course_id references section(course_id), sec_id references section(sec_id), semester references section(semester), year references section(year) | 100 |
| time_slot | time_slot_id |  | 20 |
