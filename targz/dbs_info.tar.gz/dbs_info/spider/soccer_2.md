| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| College | cName |  | 4 |
| Player | pID |  | 6 |
| Tryout | pID | cName references College(cName), pID references Player(pID) | 6 |
