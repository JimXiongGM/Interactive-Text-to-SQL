| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Customer_Payment_Methods |  | customer_id references Customers(customer_id) | 15 |
| Customers | customer_id |  | 15 |
| Invoices | invoice_number |  | 15 |
| Order_Items | order_item_id | order_id references Orders(order_id), product_id references Products(product_id) | 15 |
| Orders | order_id | customer_id references Customers(customer_id) | 20 |
| Products | product_id |  | 5 |
| Shipment_Items | shipment_id | order_item_id references Order_Items(order_item_id), shipment_id references Shipments(shipment_id) | 6 |
| Shipments | shipment_id | order_id references Orders(order_id), invoice_number references Invoices(invoice_number) | 15 |
