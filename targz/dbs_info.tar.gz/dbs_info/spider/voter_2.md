| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Student | StuID |  | 34 |
| Voting_record |  | Class_Senator_Vote references Student(StuID), Class_President_Vote references Student(StuID), Treasurer_Vote references Student(StuID), Secretary_Vote references Student(StuID), Vice_President_Vote references Student(StuID), President_Vote references Student(StuID), StuID references Student(StuID) | 10 |
