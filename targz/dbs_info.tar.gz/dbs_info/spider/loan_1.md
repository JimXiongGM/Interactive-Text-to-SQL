| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| bank | branch_ID |  | 4 |
| customer | cust_ID | branch_ID references bank(branch_ID) | 3 |
| loan | loan_ID | cust_ID references customer(Cust_ID), branch_ID references bank(branch_ID) | 3 |
