| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| ACCOUNTS | custid |  | 7 |
| CHECKING | custid | custid references ACCOUNTS(custid) | 7 |
| SAVINGS | custid | custid references ACCOUNTS(custid) | 6 |
