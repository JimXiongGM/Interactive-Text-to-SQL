| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| customers | customerNumber | salesRepEmployeeNumber references employees(employeeNumber) | 122 |
| employees | employeeNumber | reportsTo references employees(employeeNumber), officeCode references offices(officeCode) | 23 |
| offices | officeCode |  | 7 |
| orderdetails | orderNumber | productCode references products(None), orderNumber references orders(None) | 2996 |
| orders | orderNumber | customerNumber references customers(customerNumber) | 326 |
| payments | customerNumber | customerNumber references customers(customerNumber) | 273 |
| productlines | productLine |  | 7 |
| products | productCode | productLine references productlines(productLine) | 110 |
