| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| authors | au_id |  | 23 |
| discounts |  | stor_id references stores(stor_id) | 3 |
| employee | emp_id | pub_id references publishers(pub_id), job_id references jobs(job_id) | 43 |
| jobs | job_id |  | 14 |
| pub_info | pub_id | pub_id references publishers(pub_id) | 7 |
| publishers | pub_id |  | 8 |
| roysched |  | title_id references titles(title_id) | 86 |
| sales | stor_id | title_id references titles(title_id), stor_id references stores(stor_id) | 21 |
| stores | stor_id |  | 6 |
| titleauthor | au_id | title_id references titles(title_id), au_id references authors(au_id) | 25 |
| titles | title_id | pub_id references publishers(pub_id) | 18 |
