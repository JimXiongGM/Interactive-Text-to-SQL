| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| RA | student_id | student_id references student(student_id), prof_id references prof(prof_id) | 35 |
| course | course_id |  | 13 |
| prof | prof_id |  | 10 |
| registration | course_id | student_id references student(student_id), course_id references course(course_id) | 101 |
| student | student_id |  | 38 |
