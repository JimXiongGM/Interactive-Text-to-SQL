| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Country | CountryCode |  | 247 |
| CountryNotes | Countrycode | Countrycode references Country(CountryCode), Seriescode references Series(SeriesCode) | 4857 |
| Footnotes | Countrycode | Countrycode references Country(CountryCode), Seriescode references Series(SeriesCode) | 532415 |
| Indicators | CountryCode | CountryCode references Country(CountryCode) | 5656458 |
| Series | SeriesCode |  | 1345 |
| SeriesNotes | Seriescode | Seriescode references Series(SeriesCode) | 369 |
