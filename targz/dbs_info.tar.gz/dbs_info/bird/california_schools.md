| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| frpm | CDSCode | CDSCode references schools(CDSCode) | 9986 |
| satscores | cds | cds references schools(CDSCode) | 2269 |
| schools | CDSCode |  | 17686 |
