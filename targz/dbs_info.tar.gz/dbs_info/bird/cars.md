| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| country | origin |  | 3 |
| data | ID | ID references price(ID) | 398 |
| price | ID |  | 398 |
| production | ID | ID references price(ID), ID references data(ID), country references country(origin) | 692 |
