| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| cards | id |  | 56822 |
| foreign_data | id | uuid references cards(uuid) | 229186 |
| legalities | id | uuid references cards(uuid) | 427907 |
| rulings | id | uuid references cards(uuid) | 87769 |
| set_translations | id | setCode references sets(code) | 1210 |
| sets | id |  | 551 |
