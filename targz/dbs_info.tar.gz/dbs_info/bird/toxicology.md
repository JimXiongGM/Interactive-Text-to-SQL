| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| atom | atom_id | molecule_id references molecule(molecule_id) | 12333 |
| bond | bond_id | molecule_id references molecule(molecule_id) | 12379 |
| connected | atom_id | bond_id references bond(bond_id), atom_id2 references atom(atom_id), atom_id references atom(atom_id) | 24758 |
| molecule | molecule_id |  | 343 |
