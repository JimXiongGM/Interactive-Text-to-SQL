| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| biwords | lid | w2nd references words(wid), w1st references words(wid), lid references langs(lid) | 21587486 |
| langs | lid |  | 1 |
| langs_words | lid | wid references words(wid), lid references langs(lid) | 2764996 |
| pages | pid | lid references langs(lid) | 1129144 |
| pages_words | pid | wid references words(wid), pid references pages(pid) | 129131916 |
| words | wid |  | 2764996 |
