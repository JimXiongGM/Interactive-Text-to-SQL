| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| country | id |  | 74 |
| ranking_criteria | id | ranking_system_id references ranking_system(id) | 21 |
| ranking_system | id |  | 3 |
| university | id | country_id references country(id) | 1247 |
| university_ranking_year |  | university_id references university(id), ranking_criteria_id references ranking_criteria(id) | 29612 |
| university_year |  | university_id references university(id) | 1085 |
