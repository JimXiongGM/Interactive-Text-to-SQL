| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| institution_details | unitid |  | 3798 |
| institution_grads |  | unitid references institution_details(unitid) | 1302102 |
| state_sector_details | stateid | state references institution_details(state) | 312 |
| state_sector_grads |  | stateid references state_sector_details(stateid), state references institution_details(state) | 84942 |
