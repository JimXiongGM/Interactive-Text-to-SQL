| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Award | award_id | episode_id references Episode(episode_id), person references Person(name) | 75 |
| Character_Award |  | award_id references Award(award_id) | 12 |
| Credit |  | person references Person(name), episode_id references Episode(episode_id) | 4557 |
| Episode | episode_id |  | 21 |
| Keyword | episode_id | episode_id references Episode(episode_id) | 307 |
| Person | name |  | 369 |
| Vote |  | episode_id references Episode(episode_id) | 210 |
