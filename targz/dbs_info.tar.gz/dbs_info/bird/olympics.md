| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| city | id |  | 42 |
| competitor_event |  | medal_id references medal(id), event_id references event(id), competitor_id references games_competitor(id) | 260971 |
| event | id | sport_id references sport(id) | 757 |
| games | id |  | 51 |
| games_city |  | games_id references games(id), city_id references city(id) | 52 |
| games_competitor | id | person_id references person(id), games_id references games(id) | 180252 |
| medal | id |  | 4 |
| noc_region | id |  | 231 |
| person | id |  | 128854 |
| person_region |  | region_id references noc_region(id), person_id references person(id) | 130521 |
| sport | id |  | 66 |
