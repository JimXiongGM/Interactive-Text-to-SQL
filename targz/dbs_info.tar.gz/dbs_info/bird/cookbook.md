| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Ingredient | ingredient_id |  | 3346 |
| Nutrition | recipe_id | recipe_id references Recipe(recipe_id) | 878 |
| Quantity | quantity_id | recipe_id references Nutrition(recipe_id), ingredient_id references Ingredient(ingredient_id), recipe_id references Recipe(recipe_id) | 5116 |
| Recipe | recipe_id |  | 1031 |
