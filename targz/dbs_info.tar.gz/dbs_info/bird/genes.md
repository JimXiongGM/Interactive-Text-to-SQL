| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Classification | GeneID |  | 862 |
| Genes |  | GeneID references Classification(GeneID) | 4346 |
| Interactions | GeneID1 | GeneID2 references Classification(GeneID), GeneID1 references Classification(GeneID) | 910 |
