| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| station | id |  | 70 |
| status |  |  | 71984434 |
| trip | id |  | 658901 |
| weather |  |  | 3665 |
