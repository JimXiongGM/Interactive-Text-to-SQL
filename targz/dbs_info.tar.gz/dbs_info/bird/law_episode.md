| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Award | award_id | person_id references Person(person_id), episode_id references Episode(episode_id) | 22 |
| Credit | episode_id | person_id references Person(person_id), episode_id references Episode(episode_id) | 2231 |
| Episode | episode_id |  | 24 |
| Keyword | episode_id | episode_id references Episode(episode_id) | 33 |
| Person | person_id |  | 800 |
| Vote |  | episode_id references Episode(episode_id) | 240 |
