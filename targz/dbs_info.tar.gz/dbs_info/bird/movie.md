| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| actor | ActorID |  | 2713 |
| characters | MovieID | MovieID references movie(MovieID), ActorID references actor(ActorID) | 4312 |
| movie | MovieID |  | 634 |
