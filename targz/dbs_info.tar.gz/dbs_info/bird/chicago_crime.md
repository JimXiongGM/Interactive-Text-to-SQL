| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Community_Area | community_area_no |  | 77 |
| Crime | report_no | fbi_code_no references FBI_Code(fbi_code_no), community_area_no references Community_Area(community_area_no), district_no references District(district_no), iucr_no references IUCR(iucr_no), ward_no references Ward(ward_no) | 268002 |
| District | district_no |  | 22 |
| FBI_Code | fbi_code_no |  | 26 |
| IUCR | iucr_no |  | 401 |
| Neighborhood | neighborhood_name | community_area_no references Community_Area(community_area_no) | 246 |
| Ward | ward_no |  | 50 |
