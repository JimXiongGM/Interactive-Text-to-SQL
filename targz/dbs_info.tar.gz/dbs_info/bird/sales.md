| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Customers | CustomerID |  | 19759 |
| Employees | EmployeeID |  | 22 |
| Products | ProductID |  | 504 |
| Sales | SalesID | ProductID references Products(ProductID), CustomerID references Customers(CustomerID), SalesPersonID references Employees(EmployeeID) | 6715221 |
