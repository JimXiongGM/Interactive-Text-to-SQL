| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Air Carriers | Code |  | 1656 |
| Airlines |  | OP_CARRIER_AIRLINE_ID references Air Carriers(Code), DEST references Airports(Code), ORIGIN references Airports(Code) | 701352 |
| Airports | Code |  | 6510 |
