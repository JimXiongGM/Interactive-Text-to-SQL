| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| AwardsCoaches |  | coachID references Coaches(coachID) | 77 |
| AwardsMisc | name |  | 124 |
| AwardsPlayers | playerID | playerID references Master(playerID) | 2091 |
| Coaches | coachID | year references Teams(year), tmID references Teams(tmID) | 1812 |
| CombinedShutouts |  | IDgoalie2 references Master(playerID), IDgoalie1 references Master(playerID) | 54 |
| Goalies | playerID | playerID references Master(playerID), year references Teams(year), tmID references Teams(tmID) | 4278 |
| GoaliesSC | playerID | playerID references Master(playerID), year references Teams(year), tmID references Teams(tmID) | 31 |
| GoaliesShootout |  | playerID references Master(playerID), year references Teams(year), tmID references Teams(tmID) | 480 |
| HOF | hofID |  | 365 |
| Master |  | coachID references Coaches(coachID) | 7761 |
| Scoring |  | playerID references Master(playerID), year references Teams(year), tmID references Teams(tmID) | 45967 |
| ScoringSC |  | playerID references Master(playerID), year references Teams(year), tmID references Teams(tmID) | 284 |
| ScoringShootout |  | playerID references Master(playerID), year references Teams(year), tmID references Teams(tmID) | 2072 |
| ScoringSup |  | playerID references Master(playerID) | 137 |
| SeriesPost |  | year references Teams(year), tmIDLoser references Teams(tmID), year references Teams(year), tmIDWinner references Teams(tmID) | 832 |
| TeamSplits | year | year references Teams(year), tmID references Teams(tmID) | 1519 |
| TeamVsTeam | year | oppID references Teams(tmID), year references Teams(year), year references Teams(year), tmID references Teams(tmID) | 25602 |
| Teams | year |  | 1519 |
| TeamsHalf | year | tmID references Teams(tmID), year references Teams(year) | 41 |
| TeamsPost | year | year references Teams(year), tmID references Teams(tmID) | 927 |
| TeamsSC | year | year references Teams(year), tmID references Teams(tmID) | 30 |
| abbrev | Type |  | 58 |
