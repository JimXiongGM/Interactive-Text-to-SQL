| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| app_all | app_id |  | 113211 |
| app_events | event_id | event_id references events(event_id) | 32473067 |
| app_events_relevant | event_id | app_id references app_all(app_id), event_id references events_relevant(event_id) | 3701900 |
| app_labels |  | app_id references app_all(app_id), label_id references label_categories(label_id) | 459943 |
| events | event_id |  | 3252950 |
| events_relevant | event_id | device_id references gender_age(device_id) | 167389 |
| gender_age | device_id | device_id references phone_brand_device_model2(device_id) | 186697 |
| gender_age_test | device_id |  | 112071 |
| gender_age_train | device_id |  | 74645 |
| label_categories | label_id |  | 930 |
| phone_brand_device_model2 | device_id |  | 89200 |
| sample_submission | device_id |  | 13700 |
