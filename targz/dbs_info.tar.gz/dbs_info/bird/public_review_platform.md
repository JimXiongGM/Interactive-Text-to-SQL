| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Attributes | attribute_id |  | 80 |
| Business | business_id |  | 15585 |
| Business_Attributes | attribute_id | business_id references Business(None), attribute_id references Attributes(None) | 206934 |
| Business_Categories | business_id | category_id references Categories(None), business_id references Business(None) | 43703 |
| Business_Hours | business_id | day_id references Days(None), business_id references Business(None) | 47831 |
| Categories | category_id |  | 591 |
| Checkins | business_id | day_id references Days(None), business_id references Business(None) | 80038 |
| Compliments | compliment_id |  | 11 |
| Days | day_id |  | 7 |
| Elite | user_id | year_id references Years(None), user_id references Users(None) | 16366 |
| Reviews | business_id | user_id references Users(None), business_id references Business(None) | 322906 |
| Tips | business_id | user_id references Users(None), business_id references Business(None) | 87157 |
| Users | user_id |  | 70817 |
| Users_Compliments | compliment_id | user_id references Users(None), compliment_id references Compliments(None) | 98810 |
| Years | year_id |  | 10 |
