| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| playstore |  |  | 10840 |
| user_reviews |  | App references playstore(App) | 64286 |
