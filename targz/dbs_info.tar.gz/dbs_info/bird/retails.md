| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| customer | c_custkey | c_nationkey references nation(n_nationkey) | 150000 |
| lineitem | l_orderkey | l_partkey references partsupp(ps_partkey), l_suppkey references partsupp(ps_suppkey), l_orderkey references orders(o_orderkey) | 4423659 |
| nation | n_nationkey | n_regionkey references region(r_regionkey) | 25 |
| orders | o_orderkey | o_custkey references customer(c_custkey) | 1500000 |
| part | p_partkey |  | 200000 |
| partsupp | ps_partkey | ps_suppkey references supplier(s_suppkey), ps_partkey references part(p_partkey) | 800000 |
| region | r_regionkey |  | 5 |
| supplier | s_suppkey | s_nationkey references nation(n_nationkey) | 10000 |
