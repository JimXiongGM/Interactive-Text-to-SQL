| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Method | Id |  | 3508215 |
| MethodParameter | Id |  | 5132027 |
| Repo | Id |  | 140990 |
| Solution | Id |  | 338087 |
