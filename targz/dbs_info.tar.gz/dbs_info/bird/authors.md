| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Author | Id |  | 247030 |
| Conference | Id |  | 4545 |
| Journal | Id |  | 15151 |
| Paper | Id | JournalId references Journal(Id), ConferenceId references Conference(Id) | 2254920 |
| PaperAuthor |  | AuthorId references Author(Id), PaperId references Paper(Id) | 2315574 |
