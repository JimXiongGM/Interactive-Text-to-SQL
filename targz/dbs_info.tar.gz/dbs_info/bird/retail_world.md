| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Categories | CategoryID |  | 8 |
| Customers | CustomerID |  | 91 |
| Employees | EmployeeID |  | 10 |
| OrderDetails | OrderDetailID | ProductID references Products(ProductID), OrderID references Orders(OrderID) | 518 |
| Orders | OrderID | ShipperID references Shippers(ShipperID), CustomerID references Customers(CustomerID), EmployeeID references Employees(EmployeeID) | 196 |
| Products | ProductID | SupplierID references Suppliers(SupplierID), CategoryID references Categories(CategoryID) | 77 |
| Shippers | ShipperID |  | 3 |
| Suppliers | SupplierID |  | 29 |
