| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| categories | podcast_id | podcast_id references podcasts(None) | 210329 |
| podcasts | podcast_id |  | 108578 |
| reviews |  | podcast_id references podcasts(None) | 1964856 |
| runs |  |  | 12 |
