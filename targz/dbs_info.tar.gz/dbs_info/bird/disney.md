| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| characters | movie_title | hero references voice-actors(character) | 56 |
| director | name | name references characters(movie_title) | 56 |
| movies_total_gross | movie_title | movie_title references characters(movie_title) | 579 |
| revenue | Year |  | 26 |
| voice-actors | character | movie references characters(movie_title) | 922 |
