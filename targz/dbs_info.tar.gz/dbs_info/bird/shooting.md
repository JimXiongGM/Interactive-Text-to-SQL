| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| incidents | case_number |  | 219 |
| officers |  | case_number references incidents(case_number) | 370 |
| subjects |  | case_number references incidents(case_number) | 223 |
