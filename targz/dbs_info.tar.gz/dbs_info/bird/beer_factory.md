| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| customers | CustomerID |  | 554 |
| geolocation | LocationID | LocationID references location(LocationID) | 3 |
| location | LocationID | LocationID references geolocation(LocationID) | 3 |
| rootbeer | RootBeerID | BrandID references rootbeerbrand(BrandID), LocationID references location(LocationID), LocationID references geolocation(LocationID) | 6430 |
| rootbeerbrand | BrandID |  | 24 |
| rootbeerreview | CustomerID | BrandID references rootbeerbrand(BrandID), CustomerID references customers(CustomerID) | 713 |
| transaction | TransactionID | RootBeerID references rootbeer(RootBeerID), LocationID references location(LocationID), CustomerID references customers(CustomerID) | 6312 |
