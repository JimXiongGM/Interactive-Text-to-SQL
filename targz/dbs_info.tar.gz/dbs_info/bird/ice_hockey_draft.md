| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| PlayerInfo | ELITEID | weight references weight_info(weight_id), height references height_info(height_id) | 2171 |
| SeasonStatus |  | ELITEID references PlayerInfo(ELITEID) | 5485 |
| height_info | height_id |  | 16 |
| weight_info | weight_id |  | 46 |
