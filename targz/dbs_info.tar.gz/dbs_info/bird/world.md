| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| City | ID | CountryCode references Country(Code) | 4079 |
| Country | Code |  | 239 |
| CountryLanguage | CountryCode | CountryCode references Country(Code) | 984 |
