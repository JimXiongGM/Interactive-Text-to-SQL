| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| all_prevalences | ITEM |  | 244 |
| allergies | PATIENT | PATIENT references patients(patient), ENCOUNTER references encounters(ID) | 572 |
| careplans |  | PATIENT references patients(patient), ENCOUNTER references encounters(ID) | 12125 |
| claims | ID | ENCOUNTER references encounters(None), PATIENT references patients(None) | 20523 |
| conditions |  | DESCRIPTION references all_prevalences(ITEM), PATIENT references patients(patient), ENCOUNTER references encounters(ID) | 7040 |
| encounters | ID | PATIENT references patients(patient) | 20524 |
| immunizations | DATE | PATIENT references patients(patient), ENCOUNTER references encounters(ID) | 13189 |
| medications | START | PATIENT references patients(patient), ENCOUNTER references encounters(ID) | 6048 |
| observations |  | PATIENT references patients(patient), ENCOUNTER references encounters(ID) | 78899 |
| patients | patient |  | 1462 |
| procedures |  | PATIENT references patients(patient), ENCOUNTER references encounters(ID) | 10184 |
