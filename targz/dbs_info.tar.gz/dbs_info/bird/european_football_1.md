| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| divisions | division |  | 21 |
| matchs |  | Div references divisions(division) | 123404 |
