| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| attendance | link_to_event | link_to_member references member(member_id), link_to_event references event(event_id) | 326 |
| budget | budget_id | link_to_event references event(event_id) | 52 |
| event | event_id |  | 42 |
| expense | expense_id | link_to_member references member(member_id), link_to_budget references budget(budget_id) | 32 |
| income | income_id | link_to_member references member(member_id) | 36 |
| major | major_id |  | 113 |
| member | member_id | zip references zip_code(zip_code), link_to_major references major(major_id) | 33 |
| zip_code | zip_code |  | 41877 |
