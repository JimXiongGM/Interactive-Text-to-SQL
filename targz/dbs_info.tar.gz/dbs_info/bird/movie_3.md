| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| actor | actor_id |  | 200 |
| address | address_id | city_id references city(None) | 603 |
| category | category_id |  | 16 |
| city | city_id | country_id references country(None) | 600 |
| country | country_id |  | 109 |
| customer | customer_id | address_id references address(None), store_id references store(None) | 599 |
| film | film_id | original_language_id references language(None), language_id references language(None) | 1000 |
| film_actor | actor_id | film_id references film(None), actor_id references actor(None) | 5462 |
| film_category | film_id | category_id references category(None), film_id references film(None) | 1000 |
| film_text | film_id |  | 1000 |
| inventory | inventory_id | store_id references store(None), film_id references film(None) | 4581 |
| language | language_id |  | 6 |
| payment | payment_id | rental_id references rental(None), staff_id references staff(None), customer_id references customer(None) | 16049 |
| rental | rental_id | staff_id references staff(None), customer_id references customer(None), inventory_id references inventory(None) | 16044 |
| staff | staff_id | store_id references store(None), address_id references address(None) | 2 |
| store | store_id | address_id references address(None), manager_staff_id references staff(None) | 2 |
