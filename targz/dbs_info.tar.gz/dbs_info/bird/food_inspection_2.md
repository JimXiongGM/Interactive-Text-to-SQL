| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| employee | employee_id | supervisor references employee(employee_id) | 75 |
| establishment | license_no |  | 31642 |
| inspection | inspection_id | followup_to references inspection(inspection_id), license_no references establishment(license_no), employee_id references employee(employee_id) | 143870 |
| inspection_point | point_id |  | 46 |
| violation | inspection_id | point_id references inspection_point(point_id), inspection_id references inspection(inspection_id) | 525709 |
