| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Examination |  | ID references Patient(ID) | 806 |
| Laboratory | ID | ID references Patient(ID) | 13908 |
| Patient | ID |  | 1238 |
