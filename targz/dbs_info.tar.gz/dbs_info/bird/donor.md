| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| donations | donationid | projectid references projects(projectid) | 3097556 |
| essays |  |  | 99998 |
| projects | projectid |  | 664098 |
| resources | resourceid | projectid references projects(projectid) | 3666757 |
