| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| game | id | genre_id references genre(id) | 11317 |
| game_platform | id | platform_id references platform(id), game_publisher_id references game_publisher(id) | 16326 |
| game_publisher | id | publisher_id references publisher(id), game_id references game(id) | 11732 |
| genre | id |  | 12 |
| platform | id |  | 31 |
| publisher | id |  | 577 |
| region | id |  | 4 |
| region_sales |  | region_id references region(id), game_platform_id references game_platform(id) | 65320 |
