| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| chapters | id | work_id references works(None) | 945 |
| characters | id |  | 1266 |
| paragraphs | id | chapter_id references chapters(None), character_id references characters(None) | 35126 |
| works | id |  | 43 |
