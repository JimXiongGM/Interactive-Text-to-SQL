| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| cites | cited_paper_id |  | 4732 |
| content | paper_id | paper_id references paper(paper_id) | 105165 |
| paper | paper_id |  | 3312 |
