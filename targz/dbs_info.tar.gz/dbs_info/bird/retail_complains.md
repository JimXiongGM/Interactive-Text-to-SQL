| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| callcenterlogs | Complaint ID | rand client references client(client_id) | 3999 |
| client | client_id | district_id references district(district_id) | 5369 |
| district | district_id | state_abbrev references state(StateCode) | 77 |
| events | Complaint ID | Client_ID references client(client_id), Complaint ID references callcenterlogs(Complaint ID) | 23419 |
| reviews | Date | district_id references district(district_id) | 377 |
| state | StateCode |  | 48 |
