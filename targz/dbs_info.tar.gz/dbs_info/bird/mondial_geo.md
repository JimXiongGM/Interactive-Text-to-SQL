| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| borders | Country1 | Country2 references country(None), Country1 references country(None) | 320 |
| city | Name | Province references province(None), Country references province(None), Country references country(None) | 3111 |
| continent | Name |  | 5 |
| country | Code |  | 238 |
| desert | Name |  | 63 |
| economy | Country | Country references country(None) | 238 |
| encompasses | Country | Continent references continent(None), Country references country(None) | 242 |
| ethnicGroup | Name | Country references country(None) | 540 |
| geo_desert | Province | Province references province(None), Country references province(None), Country references country(None), Desert references desert(None) | 155 |
| geo_estuary | Province | Province references province(None), Country references province(None), Country references country(None), River references river(None) | 266 |
| geo_island | Province | Province references province(None), Country references province(None), Country references country(None), Island references island(None) | 202 |
| geo_lake | Province | Province references province(None), Country references province(None), Country references country(None), Lake references lake(None) | 254 |
| geo_mountain | Province | Province references province(None), Country references province(None), Country references country(None), Mountain references mountain(None) | 296 |
| geo_river | Province | Province references province(None), Country references province(None), Country references country(None), River references river(None) | 852 |
| geo_sea | Province | Province references province(None), Country references province(None), Country references country(None), Sea references sea(None) | 736 |
| geo_source | Province | Province references province(None), Country references province(None), Country references country(None), River references river(None) | 220 |
| isMember | Country | Organization references organization(None), Country references country(None) | 8009 |
| island | Name |  | 276 |
| islandIn |  | River references river(None), Lake references lake(None), Sea references sea(None), Island references island(None) | 350 |
| lake | Name |  | 130 |
| language | Name | Country references country(None) | 144 |
| located |  | Province references province(None), Country references province(None), City references city(None), Province references city(None), Sea references sea(None), Lake references lake(None), River references river(None), Country references country(None) | 858 |
| locatedOn | City | Province references province(None), Country references province(None), City references city(None), Province references city(None), Island references island(None), Country references country(None) | 435 |
| mergesWith | Sea1 | Sea2 references sea(None), Sea1 references sea(None) | 55 |
| mountain | Name |  | 0 |
| mountainOnIsland | Mountain | Island references island(None), Mountain references mountain(None) | 68 |
| organization | Abbreviation | Province references province(None), Country references province(None), City references city(None), Province references city(None), Country references country(None) | 154 |
| politics | Country | Dependent references country(None), Country references country(None) | 239 |
| population | Country | Country references country(None) | 238 |
| province | Name | Country references country(None) | 1450 |
| religion | Name | Country references country(None) | 454 |
| river | Name | Lake references lake(None) | 218 |
| sea | Name |  | 35 |
| target | Country | Country references country(None) | 205 |
