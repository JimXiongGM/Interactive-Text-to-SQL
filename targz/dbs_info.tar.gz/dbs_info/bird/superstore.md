| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| central_superstore | Row ID | Product ID references product(Product ID), Region references product(Region), Customer ID references people(Customer ID), Region references people(Region) | 4646 |
| east_superstore | Row ID | Product ID references product(Product ID), Region references product(Region), Customer ID references people(Customer ID), Region references people(Region) | 5696 |
| people | Customer ID |  | 2501 |
| product | Product ID |  | 5298 |
| south_superstore | Row ID | Product ID references product(Product ID), Region references product(Region), Customer ID references people(Customer ID), Region references people(Region) | 3240 |
| west_superstore | Row ID | Product ID references product(Product ID), Region references product(Region), Customer ID references people(Customer ID), Region references people(Region) | 6406 |
