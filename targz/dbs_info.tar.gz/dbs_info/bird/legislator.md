| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| current | bioguide_id |  | 541 |
| current-terms | bioguide | bioguide references current(bioguide_id) | 3078 |
| historical | bioguide_id |  | 11864 |
| historical-terms | bioguide | bioguide references historical(bioguide_id) | 11864 |
| social-media | bioguide | bioguide references current(bioguide_id) | 479 |
