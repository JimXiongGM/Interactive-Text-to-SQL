| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| cars | id | train_id references trains(id) | 63 |
| trains | id |  | 20 |
