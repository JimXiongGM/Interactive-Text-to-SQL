| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| circuits | circuitId |  | 72 |
| constructorResults | constructorResultsId | constructorId references constructors(constructorId), raceId references races(raceId) | 11082 |
| constructorStandings | constructorStandingsId | constructorId references constructors(constructorId), raceId references races(raceId) | 11836 |
| constructors | constructorId |  | 208 |
| driverStandings | driverStandingsId | driverId references drivers(driverId), raceId references races(raceId) | 31578 |
| drivers | driverId |  | 840 |
| lapTimes | raceId | driverId references drivers(driverId), raceId references races(raceId) | 420369 |
| pitStops | raceId | driverId references drivers(driverId), raceId references races(raceId) | 6070 |
| qualifying | qualifyId | constructorId references constructors(constructorId), driverId references drivers(driverId), raceId references races(raceId) | 7397 |
| races | raceId | circuitId references circuits(circuitId), year references seasons(year) | 976 |
| results | resultId | statusId references status(statusId), constructorId references constructors(constructorId), driverId references drivers(driverId), raceId references races(raceId) | 23657 |
| seasons | year |  | 68 |
| status | statusId |  | 134 |
