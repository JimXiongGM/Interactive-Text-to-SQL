| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| businesses | business_id |  | 6358 |
| inspections |  | business_id references businesses(business_id) | 23764 |
| violations |  | business_id references businesses(business_id) | 36050 |
