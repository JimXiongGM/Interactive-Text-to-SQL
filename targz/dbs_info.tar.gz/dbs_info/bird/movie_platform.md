| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| lists | list_id | user_id references lists_users(user_id) | 79565 |
| lists_users | user_id | user_id references lists(user_id), list_id references lists(list_id) | 80311 |
| movies | movie_id |  | 226087 |
| ratings |  | user_id references ratings_users(user_id), rating_id references ratings(rating_id), user_id references lists_users(user_id), movie_id references movies(movie_id) | 15517252 |
| ratings_users |  | user_id references lists_users(user_id) | 4297641 |
