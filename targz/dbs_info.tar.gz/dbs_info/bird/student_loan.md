| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| bool | name |  | 2 |
| disabled | name | name references person(name) | 95 |
| enlist |  | name references person(name) | 306 |
| enrolled | name | name references person(name) | 1194 |
| filed_for_bankrupcy | name | name references person(name) | 96 |
| longest_absense_from_school | name | name references person(name) | 1000 |
| male | name | name references person(name) | 497 |
| no_payment_due | name | bool references bool(name), name references person(name) | 1000 |
| person | name |  | 1000 |
| unemployed | name | name references person(name) | 98 |
