| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| account | account_id | district_id references district(district_id) | 4500 |
| card | card_id | disp_id references disp(disp_id) | 892 |
| client | client_id | district_id references district(district_id) | 5369 |
| disp | disp_id | client_id references client(client_id), account_id references account(account_id) | 5369 |
| district | district_id |  | 77 |
| loan | loan_id | account_id references account(account_id) | 682 |
| order | order_id | account_id references account(account_id) | 6471 |
| trans | trans_id | account_id references account(account_id) | 1056320 |
