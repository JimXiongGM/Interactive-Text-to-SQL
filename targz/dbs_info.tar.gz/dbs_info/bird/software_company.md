| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Customers | ID | GEOID references Demog(None) | 360000 |
| Demog | GEOID |  | 200 |
| Mailings1_2 | REFID | REFID references Customers(None) | 60000 |
| Sales | EVENTID | REFID references Customers(None) | 3420829 |
| mailings3 | REFID |  | 300000 |
