| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| actors | actorid |  | 98690 |
| directors | directorid |  | 2201 |
| movies | movieid |  | 3832 |
| movies2actors | movieid | actorid references actors(None), movieid references movies(None) | 138349 |
| movies2directors | movieid | directorid references directors(None), movieid references movies(None) | 4141 |
| u2base | userid | movieid references movies(None), userid references users(None) | 996159 |
| users | userid |  | 6039 |
