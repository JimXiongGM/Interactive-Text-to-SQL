| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| alignment | id |  | 4 |
| attribute | id |  | 6 |
| colour | id |  | 35 |
| gender | id |  | 3 |
| hero_attribute |  | hero_id references superhero(id), attribute_id references attribute(id) | 3738 |
| hero_power |  | power_id references superpower(id), hero_id references superhero(id) | 5825 |
| publisher | id |  | 25 |
| race | id |  | 61 |
| superhero | id | skin_colour_id references colour(id), race_id references race(id), publisher_id references publisher(id), hair_colour_id references colour(id), gender_id references gender(id), eye_colour_id references colour(id), alignment_id references alignment(id) | 750 |
| superpower | id |  | 167 |
