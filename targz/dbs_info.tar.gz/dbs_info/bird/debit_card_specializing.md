| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| customers | CustomerID |  | 32461 |
| gasstations | GasStationID |  | 5716 |
| products | ProductID |  | 591 |
| transactions_1k | TransactionID |  | 1000 |
| yearmonth | Date | CustomerID references customers(None), CustomerID references customers(None) | 383282 |
