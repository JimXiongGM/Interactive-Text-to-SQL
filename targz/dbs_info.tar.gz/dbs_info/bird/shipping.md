| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| city | city_id |  | 601 |
| customer | cust_id |  | 100 |
| driver | driver_id |  | 11 |
| shipment | ship_id | truck_id references truck(truck_id), driver_id references driver(driver_id), city_id references city(city_id), cust_id references customer(cust_id) | 960 |
| truck | truck_id |  | 12 |
