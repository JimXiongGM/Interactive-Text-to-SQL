| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| advisedBy | p_id | p_id references person(p_id), p_id_dummy references person(p_id) | 113 |
| course | course_id |  | 132 |
| person | p_id |  | 278 |
| taughtBy | course_id | course_id references course(course_id), p_id references person(p_id) | 189 |
