| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| generalinfo | id_restaurant | city references geographic(city) | 9590 |
| geographic | city |  | 168 |
| location | id_restaurant | id_restaurant references generalinfo(id_restaurant), city references geographic(city) | 9539 |
