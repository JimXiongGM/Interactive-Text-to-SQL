| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| beers | id | brewery_id references breweries(None) | 2410 |
| breweries | id |  | 558 |
