| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Country | id |  | 11 |
| League | id | country_id references country(id) | 11 |
| Match | id | away_player_11 references Player(player_api_id), away_player_10 references Player(player_api_id), away_player_9 references Player(player_api_id), away_player_8 references Player(player_api_id), away_player_7 references Player(player_api_id), away_player_6 references Player(player_api_id), away_player_5 references Player(player_api_id), away_player_4 references Player(player_api_id), away_player_3 references Player(player_api_id), away_player_2 references Player(player_api_id), away_player_1 references Player(player_api_id), home_player_11 references Player(player_api_id), home_player_10 references Player(player_api_id), home_player_9 references Player(player_api_id), home_player_8 references Player(player_api_id), home_player_7 references Player(player_api_id), home_player_6 references Player(player_api_id), home_player_5 references Player(player_api_id), home_player_4 references Player(player_api_id), home_player_3 references Player(player_api_id), home_player_2 references Player(player_api_id), home_player_1 references Player(player_api_id), away_team_api_id references Team(team_api_id), home_team_api_id references Team(team_api_id), league_id references League(None), country_id references Country(None) | 25979 |
| Player | id |  | 11060 |
| Player_Attributes | id | player_api_id references Player(player_api_id), player_fifa_api_id references Player(player_fifa_api_id) | 183978 |
| Team | id |  | 299 |
| Team_Attributes | id | team_api_id references Team(team_api_id), team_fifa_api_id references Team(team_fifa_api_id) | 1458 |
