| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Address | AddressID | StateProvinceID references StateProvince(None) | 19614 |
| AddressType | AddressTypeID |  | 6 |
| BillOfMaterials | BillOfMaterialsID | UnitMeasureCode references UnitMeasure(None), ComponentID references Product(None), ProductAssemblyID references Product(None) | 2679 |
| BusinessEntity | BusinessEntityID |  | 20777 |
| BusinessEntityAddress | BusinessEntityID | BusinessEntityID references BusinessEntity(BusinessEntityID), AddressTypeID references AddressType(AddressTypeID), AddressID references Address(AddressID) | 19614 |
| BusinessEntityContact | BusinessEntityID | PersonID references Person(BusinessEntityID), ContactTypeID references ContactType(ContactTypeID), BusinessEntityID references BusinessEntity(BusinessEntityID) | 909 |
| ContactType | ContactTypeID |  | 20 |
| CountryRegion | CountryRegionCode |  | 239 |
| CountryRegionCurrency | CountryRegionCode | CurrencyCode references Currency(CurrencyCode), CountryRegionCode references CountryRegion(CountryRegionCode) | 109 |
| CreditCard | CreditCardID |  | 19118 |
| Culture | CultureID |  | 8 |
| Currency | CurrencyCode |  | 105 |
| CurrencyRate | CurrencyRateID | ToCurrencyCode references Currency(None), FromCurrencyCode references Currency(None) | 13532 |
| Customer | CustomerID | StoreID references Store(BusinessEntityID), TerritoryID references SalesTerritory(TerritoryID), PersonID references Person(BusinessEntityID) | 0 |
| Department | DepartmentID |  | 16 |
| Document | DocumentNode | Owner references Employee(None) | 13 |
| EmailAddress | EmailAddressID | BusinessEntityID references Person(BusinessEntityID) | 19972 |
| Employee | BusinessEntityID | BusinessEntityID references Person(BusinessEntityID) | 290 |
| EmployeeDepartmentHistory | BusinessEntityID | ShiftID references Shift(None), DepartmentID references Department(None), BusinessEntityID references Employee(None) | 296 |
| EmployeePayHistory | BusinessEntityID | BusinessEntityID references Employee(None) | 316 |
| JobCandidate | JobCandidateID | BusinessEntityID references Employee(None) | 12 |
| Location | LocationID |  | 14 |
| Password | BusinessEntityID | BusinessEntityID references Person(BusinessEntityID) | 19972 |
| Person | BusinessEntityID | BusinessEntityID references BusinessEntity(BusinessEntityID) | 19972 |
| PersonCreditCard | BusinessEntityID | BusinessEntityID references Person(BusinessEntityID), CreditCardID references CreditCard(CreditCardID) | 19118 |
| PhoneNumberType | PhoneNumberTypeID |  | 3 |
| Product | ProductID | ProductModelID references ProductModel(None), ProductSubcategoryID references ProductSubcategory(None), WeightUnitMeasureCode references UnitMeasure(None), SizeUnitMeasureCode references UnitMeasure(None) | 504 |
| ProductCategory | ProductCategoryID |  | 4 |
| ProductCostHistory | ProductID | ProductID references Product(ProductID) | 395 |
| ProductDescription | ProductDescriptionID |  | 762 |
| ProductDocument | ProductID | DocumentNode references Document(DocumentNode), ProductID references Product(ProductID) | 32 |
| ProductInventory | ProductID | LocationID references Location(LocationID), ProductID references Product(ProductID) | 1069 |
| ProductListPriceHistory | ProductID | ProductID references Product(ProductID) | 395 |
| ProductModel | ProductModelID |  | 128 |
| ProductModelProductDescriptionCulture | ProductModelID | CultureID references Culture(CultureID), ProductDescriptionID references ProductDescription(ProductDescriptionID), ProductModelID references ProductModel(ProductModelID) | 762 |
| ProductPhoto | ProductPhotoID |  | 100 |
| ProductProductPhoto | ProductID | ProductPhotoID references ProductPhoto(ProductPhotoID), ProductID references Product(ProductID) | 504 |
| ProductReview | ProductReviewID | ProductID references Product(ProductID) | 4 |
| ProductSubcategory | ProductSubcategoryID | ProductCategoryID references ProductCategory(ProductCategoryID) | 37 |
| ProductVendor | ProductID | UnitMeasureCode references UnitMeasure(UnitMeasureCode), BusinessEntityID references Vendor(BusinessEntityID), ProductID references Product(ProductID) | 460 |
| PurchaseOrderDetail | PurchaseOrderDetailID | ProductID references Product(ProductID), PurchaseOrderID references PurchaseOrderHeader(PurchaseOrderID) | 8845 |
| PurchaseOrderHeader | PurchaseOrderID | ShipMethodID references ShipMethod(ShipMethodID), VendorID references Vendor(BusinessEntityID), EmployeeID references Employee(BusinessEntityID) | 4012 |
| SalesOrderDetail | SalesOrderDetailID | SpecialOfferID references SpecialOfferProduct(SpecialOfferID), ProductID references SpecialOfferProduct(ProductID), SalesOrderID references SalesOrderHeader(SalesOrderID) | 121317 |
| SalesOrderHeader | SalesOrderID | CurrencyRateID references CurrencyRate(None), CreditCardID references CreditCard(None), ShipMethodID references Address(None), ShipToAddressID references Address(None), BillToAddressID references Address(None), TerritoryID references SalesTerritory(None), SalesPersonID references SalesPerson(None), CustomerID references Customer(None) | 31465 |
| SalesOrderHeaderSalesReason | SalesOrderID | SalesReasonID references SalesReason(SalesReasonID), SalesOrderID references SalesOrderHeader(SalesOrderID) | 27647 |
| SalesPerson | BusinessEntityID | TerritoryID references SalesTerritory(TerritoryID), BusinessEntityID references Employee(BusinessEntityID) | 17 |
| SalesPersonQuotaHistory | BusinessEntityID | BusinessEntityID references SalesPerson(BusinessEntityID) | 163 |
| SalesReason | SalesReasonID |  | 10 |
| SalesTaxRate | SalesTaxRateID | StateProvinceID references StateProvince(StateProvinceID) | 29 |
| SalesTerritory | TerritoryID | CountryRegionCode references CountryRegion(CountryRegionCode) | 10 |
| SalesTerritoryHistory | BusinessEntityID | TerritoryID references SalesTerritory(TerritoryID), BusinessEntityID references SalesPerson(BusinessEntityID) | 17 |
| ScrapReason | ScrapReasonID |  | 16 |
| Shift | ShiftID |  | 3 |
| ShipMethod | ShipMethodID |  | 5 |
| ShoppingCartItem | ShoppingCartItemID | ProductID references Product(ProductID) | 3 |
| SpecialOffer | SpecialOfferID |  | 16 |
| SpecialOfferProduct | SpecialOfferID | ProductID references Product(ProductID), SpecialOfferID references SpecialOffer(SpecialOfferID) | 538 |
| StateProvince | StateProvinceID | TerritoryID references SalesTerritory(None), CountryRegionCode references CountryRegion(None) | 181 |
| Store | BusinessEntityID | SalesPersonID references SalesPerson(BusinessEntityID), BusinessEntityID references BusinessEntity(BusinessEntityID) | 701 |
| TransactionHistory | TransactionID | ProductID references Product(ProductID) | 113443 |
| TransactionHistoryArchive | TransactionID |  | 89253 |
| UnitMeasure | UnitMeasureCode |  | 38 |
| Vendor | BusinessEntityID | BusinessEntityID references BusinessEntity(BusinessEntityID) | 104 |
| WorkOrder | WorkOrderID | ScrapReasonID references ScrapReason(ScrapReasonID), ProductID references Product(ProductID) | 72591 |
| WorkOrderRouting | WorkOrderID | LocationID references Location(LocationID), WorkOrderID references WorkOrder(WorkOrderID) | 67131 |
