| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| coins | id |  | 8927 |
| historical |  |  | 4441972 |
