| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| badges | Id | UserId references users(Id) | 79851 |
| comments | Id | UserId references users(Id), PostId references posts(Id) | 174285 |
| postHistory | Id | UserId references users(Id), PostId references posts(Id) | 303155 |
| postLinks | Id | RelatedPostId references posts(Id), PostId references posts(Id) | 11102 |
| posts | Id | ParentId references posts(Id), OwnerUserId references users(Id), LastEditorUserId references users(Id) | 91966 |
| tags | Id | ExcerptPostId references posts(Id) | 1032 |
| users | Id |  | 40325 |
| votes | Id | UserId references users(Id), PostId references posts(Id) | 38930 |
