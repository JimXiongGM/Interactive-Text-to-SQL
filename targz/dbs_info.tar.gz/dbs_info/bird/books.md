| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| address | address_id | country_id references country(country_id) | 1000 |
| address_status | status_id |  | 2 |
| author | author_id |  | 9235 |
| book | book_id | publisher_id references publisher(publisher_id), language_id references book_language(language_id) | 11127 |
| book_author | book_id | book_id references book(book_id), author_id references author(author_id) | 17642 |
| book_language | language_id |  | 27 |
| country | country_id |  | 232 |
| cust_order | order_id | dest_address_id references address(None), shipping_method_id references shipping_method(None), customer_id references customer(None) | 7550 |
| customer | customer_id |  | 2000 |
| customer_address | customer_id | customer_id references customer(customer_id), address_id references address(address_id) | 3350 |
| order_history | history_id | status_id references order_status(None), order_id references cust_order(None) | 22348 |
| order_line | line_id | book_id references book(None), order_id references cust_order(None) | 7550 |
| order_status | status_id |  | 6 |
| publisher | publisher_id |  | 2264 |
| shipping_method | method_id |  | 4 |
