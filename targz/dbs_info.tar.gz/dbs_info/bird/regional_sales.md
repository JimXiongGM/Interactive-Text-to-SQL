| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Customers | CustomerID |  | 50 |
| Products | ProductID |  | 47 |
| Regions | StateCode |  | 48 |
| Sales Orders | OrderNumber | _ProductID references Products(ProductID), _StoreID references Store Locations(StoreID), _CustomerID references Customers(CustomerID), _SalesTeamID references Sales Team(SalesTeamID) | 7991 |
| Sales Team | SalesTeamID |  | 28 |
| Store Locations | StoreID | StateCode references Regions(StateCode) | 367 |
