| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| location | LocationID |  | 6211 |
| twitter | TweetID | UserID references user(UserID), LocationID references location(LocationID) | 99901 |
| user | UserID |  | 99260 |
