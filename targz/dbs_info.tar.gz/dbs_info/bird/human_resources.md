| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| employee | ssn | positionID references position(positionID), locationID references location(locationID) | 25 |
| location | locationID |  | 8 |
| position | positionID |  | 4 |
