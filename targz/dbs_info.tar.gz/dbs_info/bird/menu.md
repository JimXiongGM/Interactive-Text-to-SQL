| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Dish | id |  | 426713 |
| Menu | id |  | 17527 |
| MenuItem | id | menu_page_id references MenuPage(id), dish_id references Dish(id) | 1334410 |
| MenuPage | id | menu_id references Menu(id) | 66937 |
