| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| country | country_id |  | 88 |
| department | department_id |  | 12 |
| gender | gender_id |  | 3 |
| genre | genre_id |  | 20 |
| keyword | keyword_id |  | 9794 |
| language | language_id |  | 88 |
| language_role | role_id |  | 2 |
| movie | movie_id |  | 4627 |
| movie_cast |  | person_id references person(person_id), movie_id references movie(movie_id), gender_id references gender(gender_id) | 59083 |
| movie_company |  | company_id references production_company(None), movie_id references movie(None) | 13677 |
| movie_crew |  | person_id references person(person_id), movie_id references movie(movie_id), department_id references department(department_id) | 129581 |
| movie_genres |  | movie_id references movie(movie_id), genre_id references genre(genre_id) | 12160 |
| movie_keywords |  | keyword_id references keyword(None), movie_id references movie(None) | 36162 |
| movie_languages |  | language_role_id references language_role(role_id), movie_id references movie(movie_id), language_id references language(language_id) | 11740 |
| person | person_id |  | 104838 |
| production_company | company_id |  | 5047 |
| production_country |  | movie_id references movie(movie_id), country_id references country(country_id) | 6436 |
