| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| tags | index | id references torrents(None) | 161283 |
| torrents | id |  | 75719 |
