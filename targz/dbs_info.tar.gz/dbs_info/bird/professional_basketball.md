| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| awards_coaches | id | coachID references coaches(coachID), year references coaches(year) | 61 |
| awards_players | playerID | playerID references players(playerID) | 1719 |
| coaches | coachID | tmID references teams(tmID), year references teams(year) | 1689 |
| draft | id | tmID references teams(tmID), draftYear references teams(year) | 8621 |
| player_allstar | playerID | playerID references players(playerID) | 1608 |
| players | playerID |  | 5062 |
| players_teams | id | tmID references teams(tmID), year references teams(year), playerID references players(None) | 23751 |
| series_post | id | tmIDLoser references teams(tmID), year references teams(year), tmIDWinner references teams(tmID), year references teams(year) | 775 |
| teams | year |  | 1536 |
