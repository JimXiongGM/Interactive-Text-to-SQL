| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Ball_by_Ball | Match_Id | Match_Id references Match(Match_Id) | 136590 |
| Batsman_Scored | Match_Id | Match_Id references Match(Match_Id) | 133097 |
| Batting_Style | Batting_Id |  | 2 |
| Bowling_Style | Bowling_Id |  | 14 |
| City | City_Id |  | 29 |
| Country | Country_Id | Country_Id references Country(Country_Id) | 12 |
| Extra_Runs | Match_Id | Extra_Type_Id references Extra_Type(Extra_Id) | 7469 |
| Extra_Type | Extra_Id |  | 5 |
| Match | Match_Id | Man_of_the_Match references Player(Player_Id), Match_Winner references Team(Team_Id), Outcome_type references Out_Type(Out_Id), Win_Type references Win_By(Win_Id), Toss_Decide references Toss_Decision(Toss_Id), Toss_Winner references Team(Team_Id), Venue_Id references Venue(Venue_Id), Season_Id references Season(Season_Id), Team_2 references Team(Team_Id), Team_1 references Team(Team_Id) | 577 |
| Out_Type | Out_Id |  | 9 |
| Outcome | Outcome_Id |  | 3 |
| Player | Player_Id | Country_Name references Country(Country_Id), Bowling_skill references Bowling_Style(Bowling_Id), Batting_hand references Batting_Style(Batting_Id) | 469 |
| Player_Match | Match_Id | Role_Id references Rolee(Role_Id), Team_Id references Team(Team_Id), Player_Id references Player(Player_Id), Match_Id references Match(Match_Id) | 12694 |
| Rolee | Role_Id |  | 4 |
| Season | Season_Id |  | 9 |
| Team | Team_Id |  | 13 |
| Toss_Decision | Toss_Id |  | 2 |
| Umpire | Umpire_Id | Umpire_Country references Country(Country_Id) | 52 |
| Venue | Venue_Id | City_Id references City(City_Id) | 35 |
| Wicket_Taken | Match_Id | Fielders references Player(Player_Id), Kind_Out references Out_Type(Out_Id), Player_Out references Player(Player_Id), Match_Id references Match(Match_Id) | 6727 |
| Win_By | Win_Id |  | 4 |
