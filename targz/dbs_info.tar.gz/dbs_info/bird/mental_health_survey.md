| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| Answer | UserID | QuestionID references Question(None), SurveyID references Survey(None) | 234640 |
| Question | questionid |  | 105 |
| Survey | SurveyID |  | 5 |
