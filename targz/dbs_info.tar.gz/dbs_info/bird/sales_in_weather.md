| Table | Primary Key | Foreign Key | Row Count |
| --- | --- | --- | --- |
| relation | store_nbr | station_nbr references weather(station_nbr), store_nbr references sales_in_weather(store_nbr) | 45 |
| sales_in_weather | store_nbr |  | 4617600 |
| weather | station_nbr |  | 20517 |
